﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class glogin1 : Form
    {
        public glogin1()
        {
            InitializeComponent();
        }
        public void addwind(Control c)
        {
            c.Dock = DockStyle.Fill;
            panel5.Controls.Clear();
            panel5.Controls.Add(c);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sys1 s1 = new sys1();
            addwind(s1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sys2 s2 = new sys2();
            addwind(s2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sys3 s3 = new sys3();
            addwind(s3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            sys4 s4 = new sys4();
            addwind(s4);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            sys5 s5 = new sys5();
            addwind(s5);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            sys6 s6 = new sys6();
            addwind(s6);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            sys7 s7 = new sys7();
            addwind(s7);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            sys8 s8= new sys8();
            addwind(s8);
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
