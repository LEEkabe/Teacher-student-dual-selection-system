﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != null) && (textBox2.Text != null))
            {
                if (textBox1.Text == "admin2" && textBox2.Text == "12345")
                {
                    login1 m = new login1();
                    m.ShowDialog();
                }
                else
                {
                    MessageBox.Show("用户名或密码错误");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
            }
            else
            {
                MessageBox.Show("请输入用户名和密码", "提示");
            }
        }
    }
}
