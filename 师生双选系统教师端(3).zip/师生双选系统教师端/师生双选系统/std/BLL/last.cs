﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
   public  class last
    {
        DAL.last dal = new DAL.last();
        public Model.last Getlast(string id)
        {
            return dal.Getlast(id);
        }
        public Model.last Getlast1(string g_id)
        {
            return dal.Getlast1(g_id);
        }
    }
}
