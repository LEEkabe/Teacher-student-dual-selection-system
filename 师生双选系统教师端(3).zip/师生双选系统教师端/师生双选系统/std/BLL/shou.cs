﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class shou
    {
        DAL.shou messT = new DAL.shou();

        public bool shou1(Model.shou table)
        {

            bool mT = messT.shou1(table);

            return true;
        }
    }
}
