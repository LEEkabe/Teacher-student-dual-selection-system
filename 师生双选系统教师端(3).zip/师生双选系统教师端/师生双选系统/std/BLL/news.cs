﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
   public class news
    {
        public DataTable abs(string userName)
        {
            DAL.news d_t = new DAL.news();
            DataTable dt = d_t.abs(userName);
            return dt;
        }
      
    }
}
