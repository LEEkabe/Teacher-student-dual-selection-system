﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class tijiao
    {
        DAL.tijiao messT = new DAL.tijiao();
        public Model.tijiao Getsid(string studentmaster)
        {
            return messT.Getsid(studentmaster);
        }
        public bool tijiao1(Model.tijiao table)
        {

            bool mT = messT.tijiao1(table);

            return true;
        }
        public Model.tijiao GG(string id)
        {
            return messT.GG(id);
        }
        public Model.tijiao SJ(string profession,string grade )
        {
            return messT.SJ(profession,grade);
        }
    }
}
