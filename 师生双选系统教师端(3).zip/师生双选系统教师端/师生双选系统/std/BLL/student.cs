﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace BLL
{
    public class student
    {
        public DataTable get_list(string grade, string profession)
        {
            DAL.student d_t = new DAL.student();
            DataTable dt = d_t.get_list(grade,profession);
            return dt;
        }
    }
}
