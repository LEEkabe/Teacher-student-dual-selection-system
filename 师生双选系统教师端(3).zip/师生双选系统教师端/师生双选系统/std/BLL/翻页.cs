﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class 翻页
    {
        DAL.翻页 dal = new DAL.翻页();
        public DataTable GetPage(Model.翻页 m_gp)
        {
            return dal.GetPage(m_gp);
        }
    }
}
