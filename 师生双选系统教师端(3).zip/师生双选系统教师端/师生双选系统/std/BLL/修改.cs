﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class 修改

    {
        DAL.修改 user = new DAL.修改();
        public bool Updateteacher(Model.User model)
        {
            return user.Updateteacher(model);
        }

    }
}
