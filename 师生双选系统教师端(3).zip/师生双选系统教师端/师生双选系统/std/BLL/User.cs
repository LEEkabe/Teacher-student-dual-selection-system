﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class User
    {
        DAL.User user = new DAL.User();
        public bool Login(string userName, string userPassword)
        {
            return user.Login(userName, userPassword);
        }
        public bool Update(Model.User model)
        {
            return user.Update(model);
        }
        DAL.User dal = new DAL.User();
        public Model.User GetMore(string userName)
        {
            return dal.GetMore(userName);
        }
       
        public Model.User Getname(string userName)
        {
            return dal.Getname(userName);
        }

        public DataTable list_user()
        {
            DAL.User d_user = new DAL.User();
            DataTable dt = d_user.List_user();
            return dt;
        }
    }
}
