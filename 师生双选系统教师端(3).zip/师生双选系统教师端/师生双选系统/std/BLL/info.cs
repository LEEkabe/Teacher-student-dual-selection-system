﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
   public class info
    {
        
        public DataTable Getstudent(Model.info studentinfo)
        {
            DAL.info d_t = new DAL.info();
            DataTable dt = d_t.Getstudent(studentinfo);
            return dt;
        }
        public DataTable Getstudent1(Model.info studentinfo1)
        {
            DAL.info d_t = new DAL.info();
            DataTable dt = d_t.Getstudent1(studentinfo1);
            return dt;
        }
        public DataTable Getstudent2()
        {
            DAL.info d_t = new DAL.info();
            DataTable dt = d_t.Getstudent2();
            return dt;
        }
        public DataTable Getstudent3(Model.info studentinfo3)
        {
            DAL.info d_t = new DAL.info();
            DataTable dt = d_t.Getstudent3(studentinfo3);
            return dt;
        }



    }
}
