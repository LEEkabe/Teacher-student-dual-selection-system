﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class Group
    {
        DAL.Group dal = new DAL.Group();


        public bool sel_student(Model.Group model, out string msg)
        {
            bool res = false;
            res = dal.sel_student(model, out msg);

            return res;
        }
        public bool Add(Model.Group model,out string msg)
        {
            bool res = false;
            res = dal.Add(model, out msg);
            msg = "ok";

            return res;
        }



    }
}
