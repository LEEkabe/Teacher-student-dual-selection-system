﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class Group
    {
        public bool sel_student(Model.Group m_group, out string msg)
        {
            string sql = "update [5_8_tea] set name=@name,id=@id,grade=@grade,profession=@profession,d1=@d1, d1id=@d1id, d2=@d2,d2id=@d2id, d3=@d3, d3id=@d3id,d4=@d4, d4id=@d4id, d5=@d5,d5id=@d5id,count=@count";
            SqlParameter[] sps = new SqlParameter[15];
            sps[0] = new SqlParameter("@name", m_group.name);
            sps[1] = new SqlParameter("@id", m_group.id);
            sps[2] = new SqlParameter("@grade", m_group.grade);    
            sps[3] = new SqlParameter("@profession", m_group.profession);
            sps[4] = new SqlParameter("@d1", m_group.d1);
            sps[5] = new SqlParameter("@d1id", m_group.d1id);
            sps[6] = new SqlParameter("@d2", m_group.d2);
            sps[7] = new SqlParameter("@d2id", m_group.d2id);
            sps[8] = new SqlParameter("@d3", m_group.d3);
            sps[9] = new SqlParameter("@d3id", m_group.d3id);
            sps[10] = new SqlParameter("@d4", m_group.d4);
            sps[11] = new SqlParameter("@d4id", m_group.d4id);
            sps[12] = new SqlParameter("@d5", m_group.d5);
            sps[13] = new SqlParameter("@d5id", m_group.d5id);
            sps[14] = new SqlParameter("@count", m_group.count);
           

            int res = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, sps);
            if (res == 1)
            {
                msg = "ok!";
                return true;
            }
            msg = "wrong!";
            return false;
        }
        public bool Add(Model.Group model,out string msg)
        {
            StringBuilder strSql = new StringBuilder();      
            strSql.Append("insert into [5_8_tea](");
            strSql.Append("name,id,grade,profession)");
            strSql.Append(" values (");
            strSql.Append("@name,@id,@grade,@profession)");
            SqlParameter[] parameters = {
                    new SqlParameter("@name", SqlDbType.Char,10),
                    new SqlParameter("@id", SqlDbType.Char,20),
                    new SqlParameter("@grade", SqlDbType.Char,10),
                    new SqlParameter("@profession", SqlDbType.Char,10),                   
            };
        parameters[0].Value = model.name;
            parameters[1].Value = model.id;
            parameters[2].Value = model.grade;
            parameters[3].Value = model.profession;          
            int rows = SqlDbHelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
            if (rows > 0)
            {
                msg = "ok";
                return true;
                
            }
            else
            {
                msg = "false";
                return false;
            }
        }

    }
}


