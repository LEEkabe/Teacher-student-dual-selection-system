﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
    public class 修改
    {
        public bool Updateteacher(Model.User model)
        {

          
            string strSql = string.Format("update [ateacher] set id=@id,name=@name,sex=@sex,grade=@grade,profession=@profession,year=@year,jobtitle=@jobtitle,academy=@academy,major=@major,phone=@phone where userName=@userName");


            SqlParameter[] parameters = {
                                       new SqlParameter("@userName", SqlDbType.VarChar,10),
                                       new SqlParameter("@name", SqlDbType.VarChar,10),
                                       new SqlParameter("@id", SqlDbType.VarChar,11),
                                       new SqlParameter("@sex", SqlDbType.VarChar,10),
                                       new SqlParameter("@profession", SqlDbType.VarChar,10),
                                       new SqlParameter("@year", SqlDbType.VarChar,10),
                                       new SqlParameter("@grade", SqlDbType.VarChar,10),
                                       new SqlParameter("@academy", SqlDbType.VarChar,10),
                                       new SqlParameter("@phone", SqlDbType.VarChar,11),
                                       new SqlParameter("@major", SqlDbType.VarChar,30),
                                       new SqlParameter("@jobtitle", SqlDbType.VarChar,10),
            };
            parameters[0].Value = model.userName;
            parameters[1].Value = model.name;
            parameters[2].Value = model.id;
            parameters[3].Value = model.sex;
            parameters[4].Value = model.profession;
            parameters[5].Value = model.year;
            parameters[6].Value = model.academy;
            parameters[7].Value = model.grade;
            parameters[8].Value = model.phone;
            parameters[9].Value = model.major;
            parameters[10].Value = model.jobtitle;
            int row = SqlDbHelper.ExecuteNonQuery(strSql, CommandType.Text, parameters);

            if (row == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


    }
}
