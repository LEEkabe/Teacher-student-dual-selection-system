﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class info
    {
       
        public DataTable Getstudent(Model.info studentinfo)
        {
            string sql = "Select * from [5_8_student] where studentgrade=@studentgrade";
            SqlParameter[] sps = new SqlParameter[1];
            sps[0] = new SqlParameter("@studentgrade ", studentinfo.studentgrade);          
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getstudent1(Model.info studentinfo1)
        {
            string sql = "Select * from [5_8_student] where studentprofession=@studentprofession";
            SqlParameter[] sps = new SqlParameter[1];
            sps[0] = new SqlParameter("@studentprofession", studentinfo1.studentprofession);
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getstudent2()
        {
            string sql = string.Format("select * from [5_8_student]");
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql);
            return dt;
        }
        public DataTable Getstudent3(Model.info studentinfo3)
        {
            string sql = "Select * from [5_8_student] where studentgrade=@studentgrade and studentprofession=@studentprofession";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@studentgrade ", studentinfo3.studentgrade);
            sps[1] = new SqlParameter("@studentprofession", studentinfo3.studentprofession);
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
    }
}
