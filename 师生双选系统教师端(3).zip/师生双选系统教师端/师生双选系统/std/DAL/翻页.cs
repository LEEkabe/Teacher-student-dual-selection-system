﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class 翻页
    {
      
        public DataTable GetPage(Model.翻页 m_gp)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("Pages");
            SqlParameter[] parameters;
            parameters = new SqlParameter[] {
                    new SqlParameter("@PageIndex", m_gp.pageIndex),
                    new SqlParameter("@PageSize", m_gp.pageSize),
                    new SqlParameter("@RecordCount", m_gp.recordCount),
                    new SqlParameter("@PageCount", m_gp.pageCount),

            };
            parameters[2].Direction = ParameterDirection.Output;
            parameters[3].Direction = ParameterDirection.Output;

            DataTable res = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.StoredProcedure, parameters);
            m_gp.recordCount = (int)parameters[2].Value;
            m_gp.pageCount = (int)parameters[3].Value;
            return res;
        }
    }
}
