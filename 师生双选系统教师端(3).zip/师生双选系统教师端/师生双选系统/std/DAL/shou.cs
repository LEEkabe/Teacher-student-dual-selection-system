﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class shou
    {
        public bool shou1(Model.shou table)
        {
            

            string sql = string.Format("insert into [5_8_send](sender,grade,profession,time,messcontent,receiver) values(@sender,@grade,@profession,@time,@messcontent,@receiver)");
            SqlParameter[] d_sps = new SqlParameter[6];
            d_sps[0] = new SqlParameter("@sender ", table.sender);
            d_sps[1] = new SqlParameter("@grade ", table.grade);
            d_sps[2] = new SqlParameter("@profession ", table.profession);
            d_sps[3] = new SqlParameter("@time ", table.time);
           
            d_sps[4] = new SqlParameter("@messcontent ", table.messContent);
            d_sps[5] = new SqlParameter("@receiver ", table.receiver);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

            return true;
        }
    }
}
