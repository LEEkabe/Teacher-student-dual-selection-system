﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class User
    {
        //登录
        #region login
        public bool Login(string userName, string userPassword)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select userName,userPassword from [ateacher]");
            strSql.Append(" where userName=@userName and userPassword=@userPassword");
            SqlParameter[] parameters = {
                    new SqlParameter("@userName", SqlDbType.VarChar,11),
                    new SqlParameter("@userPassword", SqlDbType.VarChar,30),};
            parameters[0].Value = userName;
            parameters[1].Value = userPassword;
           DataTable data= SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count == 1)
                return true;
            else
                return false;
        }
        #endregion

        //修改密码
        #region change the password
        public  bool Update(Model.User model)
        {
            
            
           string strSql= string.Format("update [ateacher] set userPassword=@userPassword where userName=@userName");
           

           SqlParameter[] parameters = {
                                       new SqlParameter("@userName", SqlDbType.VarChar,11),
                                       new SqlParameter("@userPassword", SqlDbType.VarChar,30),
            };
            parameters[0].Value = model.userName;
            parameters[1].Value = model.userPassword;
           int row= SqlDbHelper.ExecuteNonQuery(strSql, CommandType.Text, parameters);
           
            if (row==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
        //导师个人信息查看
        #region search for teacher information
        public Model.User GetMore(string userName)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select name,id,sex,year,academy,profession,grade,jobtitle,phone,major from [ateacher]");
            strSql.Append(" where userName=@userName");
            SqlParameter[] parameters = {
                    new SqlParameter("@userName", SqlDbType.Char,30) };
            parameters[0].Value = userName;
            Model.User model = new Model.User();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.name = data.Rows[0][0].ToString();
                model.id= data.Rows[0][1].ToString();
                model.sex = data.Rows[0][2].ToString();
                model.year = data.Rows[0][3].ToString();               
                model.academy = data.Rows[0][4].ToString();
                model.profession = data.Rows[0][5].ToString();
                model.grade = data.Rows[0][6].ToString();
                model.jobtitle = data.Rows[0][7].ToString();
                model.phone = data.Rows[0][8].ToString();                             
                model.major = data.Rows[0][9].ToString();                                             
                return model;
            }
            else
            {
                return null;
            }
        }
        public Model.User Getname(string userName)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select name,id from [ateacher]");
            strSql.Append(" where userName=@userName");
            SqlParameter[] parameters = {
                    new SqlParameter("@userName", SqlDbType.Char,30) };
            parameters[0].Value = userName;
            Model.User model = new Model.User();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.name = data.Rows[0][0].ToString();
                model.id = data.Rows[0][1].ToString();

                return model;
            }
            else
            {
                return null;
            }
        }
            #endregion
            

            public DataTable List_user()
        {
            string sql = string.Format("select * from [5_8_team]");
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql);
            return dt;
        }

    }
}
