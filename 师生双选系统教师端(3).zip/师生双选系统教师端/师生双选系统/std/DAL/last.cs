﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class last
    {      
        public Model.last Getlast(string id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select g1,g2,g3,g4,g5 from [5_8_tea] where id=@id");

            SqlParameter[] parameters = {
                    new SqlParameter("@id", SqlDbType.Char,30) };
            parameters[0].Value = id;
            Model.last model = new Model.last();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.g1 = data.Rows[0][0].ToString();
                model.g2= data.Rows[0][1].ToString();
                model.g3 = data.Rows[0][2].ToString();
                model.g4 = data.Rows[0][3].ToString();
                model.g5 = data.Rows[0][4].ToString();
                
                return model;
            }
            else
            {
                return null;
            }
        }
        public Model.last Getlast1(string g_id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select teamname,master from [5_8_group] where g_id=@g_id");

            SqlParameter[] parameters = {
                    new SqlParameter("@g_id", SqlDbType.Char,30) };
            parameters[0].Value = g_id;
            Model.last model = new Model.last();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.teamname = data.Rows[0][0].ToString();
                model.master = data.Rows[0][1].ToString();
               
                return model;
            }
            else
            {
                return null;
            }
        }

    }
}
