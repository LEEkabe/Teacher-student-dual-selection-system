﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class student
    {
        public DataTable get_list(string grade,string profession)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * from [5_8_team] where teamgrade=@grade and teamprofession=@profession");
            SqlParameter[] parameters = {
                    new SqlParameter("@grade", SqlDbType.Char,30),
                    new SqlParameter("@profession", SqlDbType.Char,30),
            };
            parameters[0].Value = grade;
            parameters[1].Value = profession;

            DataTable dt = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            return dt;
        }
    }
}
//, CommandType.Text, sps
