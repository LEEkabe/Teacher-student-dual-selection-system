﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
   public class news
    {
        public Model.User GetMore(string userName)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select name,id,sex,year,academy,profession,grade,jobtitle,phone,major from [ateacher]");
            strSql.Append(" where userName=@userName");
            SqlParameter[] parameters = {
                    new SqlParameter("@userName", SqlDbType.Char,30) };
            parameters[0].Value = userName;
            Model.User model = new Model.User();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.name = data.Rows[0][0].ToString();
                model.id = data.Rows[0][1].ToString();
                model.sex = data.Rows[0][2].ToString();
                model.year = data.Rows[0][3].ToString();
                model.academy = data.Rows[0][4].ToString();
                model.profession = data.Rows[0][5].ToString();
                model.grade = data.Rows[0][6].ToString();
                model.jobtitle = data.Rows[0][7].ToString();
                model.phone = data.Rows[0][8].ToString();
                model.major = data.Rows[0][9].ToString();
                return model;
            }
            else
            {
                return null;
            }
        }
        public DataTable abs(string userName)
        {           
            
            Model.User model1 = GetMore(userName);
            Model.news nw = new Model.news();
            StringBuilder str= new StringBuilder();
            str.Append("select time,title,messcontent from [5_8_send] ");
            str.Append(" where receiver='老师' and grade=@newgrade and profession=@newprofession");
            SqlParameter[] parameters1 = {
                   new SqlParameter("@newgrade", SqlDbType.VarChar,11),
            new SqlParameter("@newprofession", SqlDbType.VarChar,30)};
            
            parameters1[0].Value = model1.grade;
            parameters1[1].Value = model1.profession;
            DataTable dt= SqlDbHelper.ExecuteDataTable(str.ToString(), CommandType.Text, parameters1);
            return dt;
        }
       
        
    }
}

