﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public  class tijiao
    {
        public Model.tijiao Getsid(string studentmaster)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select studentmasterid from [5_8_team]");
            strSql.Append(" where studentmaster=@studentmaster");
            SqlParameter[] parameters = {
                    new SqlParameter("@studentmaster", SqlDbType.Char,30) };
            parameters[0].Value = studentmaster;
            Model.tijiao model = new Model.tijiao();
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count > 0)
            {
                model.studentmasterid= data.Rows[0][0].ToString();                               
                return model;
            }
            else
            {
                return null;
            }
        }
        public Model.tijiao GG(string id) {
            StringBuilder strSql1 = new StringBuilder();
            strSql1.Append("select count from [5_8_tea]");
            strSql1.Append(" where id=@id"); SqlParameter[] parameters1 = {
                    new SqlParameter("@id", SqlDbType.Char,30) };

            parameters1[0].Value = id;
            Model.tijiao model = new Model.tijiao();
            DataTable data1 = SqlDbHelper.ExecuteDataTable(strSql1.ToString(), CommandType.Text, parameters1);
            if (data1.Rows.Count > 0)
            {
                model.count = data1.Rows[0][0].ToString();
                return model;
            }
            else
            {
                model.count = "0";
                return model;
            }
        }

        public Model.tijiao GH()//次数规则
        {
            StringBuilder strSql1 = new StringBuilder();
            strSql1.Append("select count from [5_8_rule]");
            
            Model.tijiao model = new Model.tijiao();
            DataTable data1 = SqlDbHelper.ExecuteDataTable(strSql1.ToString(), CommandType.Text);
            if (data1.Rows.Count > 0)
            {
                model.count1 = data1.Rows[0][0].ToString();
                return model;
            }
            else
            {                
                return null;
            }
        }

        public Model.tijiao  SJ (string profession,string grade)//时间规则
        {
            StringBuilder strSql1 = new StringBuilder();
            strSql1.Append("select ddl,start from [5_8_rule] ");
            strSql1.Append(" where profession=@profession and grade=@grade");
            SqlParameter[] parameters1 = {
                   
                    new SqlParameter("@profession", SqlDbType.Char,30),
                    new SqlParameter("@grade", SqlDbType.Char,30)
            };

            
            parameters1[0].Value = profession;
            parameters1[1].Value = grade;


            Model.tijiao model =new Model.tijiao();

            DataTable data1 = SqlDbHelper.ExecuteDataTable(strSql1.ToString(), CommandType.Text,parameters1);
            if (data1.Rows.Count > 0)
            {
                model.ddl = data1.Rows[0][0].ToString();
                model.start = data1.Rows[0][1].ToString();               
                
                return model;
            }
            else
            {
                return null;
            }
        }

        public bool tijiao1(Model.tijiao table)
        {           
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select name from [5_8_tea]");
            strSql.Append(" where id=@id"); SqlParameter[] parameters = {
                    new SqlParameter("@id", SqlDbType.Char,30) };
            parameters[0].Value = table.id;         
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count == 1)
            {
                string b = table.count;
                int a = Convert.ToInt32(b);
                Model.tijiao cc = GH();
                string c = cc.count1;
                int e= Convert.ToInt32(c);
                if (a<= e)
                {

                    string sqr = string.Format("update [5_8_tea] set d1=@d1,d1id=@d1id,d2=@d2,d2id=@d2id,d3=@d3,d3id=@d3id,d4=@d4,d4id=@d4id,d5=@d5,d5id=@d5id,count=@count where id=@id");


                    SqlParameter[] par = {
                                            new SqlParameter("@id", SqlDbType.VarChar,11),
                                       new SqlParameter("@d1", SqlDbType.VarChar,11),
                                       new SqlParameter("@d1id", SqlDbType.VarChar,10),
                                       new SqlParameter("@d2", SqlDbType.VarChar,11),
                                       new SqlParameter("@d2id", SqlDbType.VarChar,10),
                                       new SqlParameter("@d3", SqlDbType.VarChar,10),
                                       new SqlParameter("@d3id", SqlDbType.VarChar,10),
                                       new SqlParameter("@d4", SqlDbType.VarChar,10),
                                       new SqlParameter("@d4id", SqlDbType.VarChar,10),
                                       new SqlParameter("@d5", SqlDbType.VarChar,11),
                                       new SqlParameter("@d5id", SqlDbType.VarChar,30),
                                       new SqlParameter("@count", SqlDbType.Int,30),

            };
                    par[0].Value = table.id;
                    par[1].Value = table.d1;
                    par[2].Value = table.d1id;
                    par[3].Value = table.d2;
                    par[4].Value = table.d2id;
                    par[5].Value = table.d3;
                    par[6].Value = table.d3id;
                    par[7].Value = table.d4;
                    par[8].Value = table.d4id;
                    par[9].Value = table.d5;
                    par[10].Value = table.d5id;
                    par[11].Value = table.count;

                    int row = SqlDbHelper.ExecuteNonQuery(sqr, CommandType.Text, par);

                    if (row == 1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
                else {
                    return false;
                }
            }
            else
            {
                string sql = string.Format("insert into [5_8_tea](name,id,profession,grade,d1,d1id,d2,d2id,d3,d3id,d4,d4id,d5,d5id,count) values(@name,@id,@profession,@grade,@d1,@d1id,@d2,@d2id,@d3,@d3id,@d4,@d4id,@d5,@d5id,@count)");
                SqlParameter[] d_sps = new SqlParameter[15];
                table.count = "0";
                d_sps[0] = new SqlParameter("@name ", table.name);
                d_sps[1] = new SqlParameter("@grade ", table.grade);
                d_sps[2] = new SqlParameter("@profession ", table.profession);
                d_sps[3] = new SqlParameter("@id ", table.id);
                d_sps[4] = new SqlParameter("@d1 ", table.d1);
                d_sps[5] = new SqlParameter("@d1id ", table.d1id);
                d_sps[6] = new SqlParameter("@d2 ", table.d2);
                d_sps[7] = new SqlParameter("@d2id ", table.d2id);
                d_sps[8] = new SqlParameter("@d3 ", table.d3);
                d_sps[9] = new SqlParameter("@d3id ", table.d3id);
                d_sps[10] = new SqlParameter("@d4 ", table.d4);
                d_sps[11] = new SqlParameter("@d4id ", table.d4id);
                d_sps[12] = new SqlParameter("@d5 ", table.d5);
                d_sps[13] = new SqlParameter("@d5id ", table.d5id);
                d_sps[14] = new SqlParameter("@count ", table.count);

                DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

                return true;
            }
        }
    }
}
