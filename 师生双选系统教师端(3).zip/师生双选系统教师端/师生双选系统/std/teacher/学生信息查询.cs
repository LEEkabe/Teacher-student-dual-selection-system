﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace teacher
{
    public partial class 学生信息查询 : UserControl
    {
      
        DataTable dt_student;

        public 学生信息查询()
        {
            InitializeComponent();
        }

        private void t4_Load(object sender, EventArgs e)
        {
           if (comboBox1.Text == "" && comboBox3.Text == "")
            {
                BLL.info bll = new BLL.info();
                dt_student = bll.Getstudent2();
                this.dataGridView1.DataSource = dt_student;
            }
            dataGridView1.Columns[0].HeaderText = "姓名";
            dataGridView1.Columns[1].HeaderText = "学号";            
            dataGridView1.Columns[2].HeaderText = "班级";
            dataGridView1.Columns[3].HeaderText = "专业";
            dataGridView1.Columns[4].HeaderText = "学院";
            dataGridView1.Columns[5].HeaderText = "年级";
            dataGridView1.Columns[6].HeaderText = "电话号码";
            dataGridView1.Columns[7].HeaderText = "性别";
            dataGridView1.Columns[8].HeaderText = "年龄";
            dataGridView1.Columns[9].HeaderText = "身份";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && comboBox3.Text != "")
            {               
                Model.info model = new Model.info();
                model.studentgrade = comboBox1.Text;
                model.studentprofession = comboBox3.Text;
                BLL.info bll = new BLL.info();
                dt_student = bll.Getstudent3(model);              
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text != "" && comboBox3.Text == "")
            {
                
                Model.info model = new Model.info();
                model.studentgrade = comboBox1.Text;
                BLL.info bll = new BLL.info();
                dt_student = bll.Getstudent(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text == "" && comboBox3.Text != "")
            {
                
                Model.info model = new Model.info();
                model.studentprofession = comboBox3.Text;
                BLL.info bll = new BLL.info();
                dt_student = bll.Getstudent1(model);
                this.dataGridView1.DataSource = dt_student;
            }
           else if (comboBox1.Text == "" && comboBox3.Text == "")
            {
                BLL.info bll = new BLL.info();
                dt_student = bll.Getstudent2();
                this.dataGridView1.DataSource = dt_student;
            }

        }
    }
}
