﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class 忘记密码 : UserControl
    {
        public 忘记密码()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                if (textBox2.Text.Trim() != thelp.userpassword)
            {
                MessageBox.Show("原密码错误");
                

                return;
            }
            if (textBox4.Text.Trim() == "")
            {
                MessageBox.Show("新密码不能为空");                
                textBox4.Focus();
                return;
            }
            if (textBox4.Text.Trim() != textBox1.Text)
            {
                MessageBox.Show("密码不一致，请重新输入");
                textBox4.Focus();


                return;
            }
            else
            {
                Model.User model = new Model.User();
                model.userPassword = textBox1.Text.Trim();
                model.userName = thelp.username;
                BLL.User user = new BLL.User();
                
                if (user.Update(model))
                {
                    thelp.userpassword = model.userPassword;
                    
                    MessageBox.Show("密码更新成功！");
                    Application.Restart();
                }
                else
                {
                    MessageBox.Show("密码更新失败！");
                }
            }
        }
    }
}
