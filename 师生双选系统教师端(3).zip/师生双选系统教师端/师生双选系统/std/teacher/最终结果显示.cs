﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class 最终结果显示 : UserControl
    {
        DataTable t;
        public 最终结果显示()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            gly m = new gly();
            m.ShowDialog();
        }

        private void t6_Load(object sender, EventArgs e)
        {
            BLL.last bll = new BLL.last();
            BLL.User use = new BLL.User();
            Model.User u = use.GetMore(thelp.username);
            Model.last model = bll.Getlast(u.id);
            Model.last a = bll.Getlast1(model.g1);
            if (a!=null) {
                textBox1.Text = a.teamname;
                textBox2.Text = a.master;

                Model.last b = bll.Getlast1(model.g2);
                textBox3.Text = b.teamname;
                textBox7.Text = b.master;

                Model.last c = bll.Getlast1(model.g3);
                textBox4.Text = c.teamname;
                textBox8.Text = c.master;

                Model.last d = bll.Getlast1(model.g4);
                textBox5.Text = d.teamname;
                textBox9.Text = d.master;

                Model.last f = bll.Getlast1(model.g5);
                textBox6.Text = f.teamname;
                textBox10.Text = f.master;
            }
            else
            {
                MessageBox.Show("请耐心等待结果");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
