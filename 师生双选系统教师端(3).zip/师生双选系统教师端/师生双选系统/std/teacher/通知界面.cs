﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace teacher
{
    public partial class 通知界面 : UserControl
    {
        public 通知界面()
        {
            InitializeComponent();
          
        }
        DataTable dt;
        DataTable group_page;
        Model.翻页 m_gp = new Model.翻页();
        bool error;

        public static string str = "";

        public static string str1 = "";

        
        SqlParameter[] paras = new SqlParameter[6];
        private void getPage(Model.翻页 m_gp)
        {
            BLL.翻页 b_g = new BLL.翻页();
            group_page = b_g.GetPage(m_gp);


        }


        #region
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            if (m_gp.pageIndex < 1)
                return;

            m_gp.pageIndex--;
            if (!backgroundWorker2.IsBusy)
                backgroundWorker2.RunWorkerAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (m_gp.pageIndex == m_gp.pageCount - 1)
                return;

            m_gp.pageIndex++;
            if (!backgroundWorker2.IsBusy)
                backgroundWorker2.RunWorkerAsync();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
           

        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                getPage(m_gp);
                error = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                error = true;
            }
        }

        private void backgroundWorker2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!error)
            {
                
                dataGridView1.DataSource = group_page;
                
            }
        }

        private void t1_Load(object sender, EventArgs e)
        {
            
            BLL.news bn = new BLL.news();            
            dt = bn.abs(thelp.username);
            this.dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 140;
            dataGridView1.Columns[1].Width = 140;
            dataGridView1.Columns[2].Width = 140;
            dataGridView1.Columns[0].HeaderText = "时间";
            dataGridView1.Columns[1].HeaderText = "标题";
            dataGridView1.Columns[2].HeaderText = "正文";
            dataGridView1.Font = new Font("宋体",12);


            //翻页
            m_gp.pageIndex = 0;
            m_gp.pageSize = 1;
        }

            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            str1 = dataGridView1.CurrentRow.Cells["title"].Value.ToString();
            str = dataGridView1.CurrentRow.Cells["messcontent"].Value.ToString();
                通知详情 xx = new 通知详情();
                xx.ShowDialog();            
        }
    }
}
