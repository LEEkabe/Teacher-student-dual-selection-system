﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace teacher
{
    public partial class 信息 : Form
    {
        public 信息()
        {
            InitializeComponent();
        }

        private void 信息_Load(object sender, EventArgs e)
        {
            BLL.User bll = new BLL.User();
           Model.User model = bll.Getname(thelp.username);
            textBox1.Text = model.name;
            textBox2.Text = model.id;
            this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
            this.Top = Screen.PrimaryScreen.Bounds.Height / 2 - this.Height / 2;//桌面的高度的一半减去自身高度的一半
        }
    }
}
