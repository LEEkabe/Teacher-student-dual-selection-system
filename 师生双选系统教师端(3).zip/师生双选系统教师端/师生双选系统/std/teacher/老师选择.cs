﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace teacher
{
    public partial class 老师选择 : UserControl
    {
        DataTable dt_student;
        Model.Group m_group = new Model.Group();
        int choice;
        TextBox selected;
        #region uu
        public 老师选择()
        {
           
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
          
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
         
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }
        #endregion
        private void t5_Load(object sender, EventArgs e)
        {
          
            BLL.student b_student = new BLL.student();
            BLL.User ab = new BLL.User();
            Model.User c = ab.GetMore(thelp.username);
           dt_student = b_student.get_list(c.grade,c.profession);

           dataGridView1.DataSource = dt_student;
            this.dataGridView1.Columns[1].HeaderText = "专业";
            radioButton1.Checked = true;
            selected = textBox1;
            this.choice = 1; 
            dataGridView1.Columns[0].HeaderText = "课题名";
            dataGridView1.Columns[2].HeaderText = "学院";
            dataGridView1.Columns[3].HeaderText = "年级";
            dataGridView1.Columns[4].HeaderText = "队长名";
            dataGridView1.Columns[5].HeaderText = "队长学号";
            dataGridView1.Columns[6].HeaderText = "队友一";
            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns[8].HeaderText = "队友二";
            dataGridView1.Columns[9].Visible = false;
            dataGridView1.Columns[10].HeaderText = "队友三";
            dataGridView1.Columns[11].Visible = false;
            dataGridView1.Columns[12].HeaderText = "电话号码";
        }
        #region ui
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }
 #endregion
        private void button2_Click_1(object sender, EventArgs e)
        {

        }
      

        private void button1_Click(object sender, EventArgs e)
        {
            BLL.User bll = new BLL.User();
            Model.User model = bll.GetMore(thelp.username);
          BLL.tijiao t1 = new BLL.tijiao();
           string p2= model.profession.Trim();
          string p3 = model.grade.Trim();
           
            Model.tijiao t2 = t1.SJ(p2,p3);
            DateTime time= DateTime.Now;
           
            
            DateTime s = Convert.ToDateTime(t2.start);
            DateTime d = Convert.ToDateTime(t2.ddl);
            if (s <= time && d >= time)
            {

                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
                {
                    if (textBox1.Text != textBox2.Text && textBox1.Text != textBox3.Text && textBox1.Text != textBox4.Text && textBox1.Text != textBox5.Text && textBox2.Text != textBox3.Text && textBox2.Text != textBox4.Text && textBox2.Text != textBox5.Text && textBox3.Text != textBox4.Text && textBox3.Text != textBox5.Text && textBox4.Text != textBox5.Text)
                    {

                        BLL.tijiao b_table = new BLL.tijiao();
                        
                        BLL.tijiao sid = new BLL.tijiao();

                        Model.tijiao table = new Model.tijiao();
                       


                        table.d1 = textBox1.Text.Trim();
                        Model.tijiao tijiao1 = sid.Getsid(textBox1.Text);
                        table.d1id = tijiao1.studentmasterid;

                        table.d2 = textBox2.Text;
                        Model.tijiao tijiao2 = sid.Getsid(textBox2.Text);
                        table.d2id = tijiao2.studentmasterid;

                        table.d3 = textBox3.Text;
                        Model.tijiao tijiao3 = sid.Getsid(textBox3.Text);
                        table.d3id = tijiao3.studentmasterid;

                        table.d4 = textBox4.Text;
                        Model.tijiao tijiao4 = sid.Getsid(textBox4.Text);
                        table.d4id = tijiao4.studentmasterid;

                        table.d5 = textBox5.Text;
                        Model.tijiao tijiao5 = sid.Getsid(textBox5.Text);
                        table.d5id = tijiao5.studentmasterid;

                        table.id = model.id.Trim();
                        table.name = model.name;
                        table.profession = model.profession;
                        table.grade = model.grade;

                        Model.tijiao t = sid.GG(model.id);


                        string b = t.count;
                        int a = Convert.ToInt32(b);
                        DAL.tijiao h = new DAL.tijiao();
                        Model.tijiao f= h.GH();
                        
                        int w= Convert.ToInt32(f.count1);
                        a = a + 1;
                        if (a < w)
                        {

                            b = Convert.ToString(a);
                            table.count = b;
                            bool mes = b_table.tijiao1(table);
                            MessageBox.Show("发送成功！");
                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            textBox5.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("您超过提交次数，不能再修改了");
                        }


                    }
                    else
                    {
                        MessageBox.Show("不要重复选择一只队伍");
                    }
                }
                else
                {
                    MessageBox.Show("请选择队伍");
                }
            }
           if(s>time)
            {
                MessageBox.Show("未到开始时间，请等待");
            }
           if(d<time)
            {
                MessageBox.Show("已经过时了");
            }

            }
        #region uo
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
        
        }

        private void textBox2_DragEnter(object sender, DragEventArgs e)
        {
           
        }

        private void textBox3_DragEnter(object sender, DragEventArgs e)
        {
       
        }

        private void textBox4_DragEnter(object sender, DragEventArgs e)
        {
           
        }

        private void textBox5_DragEnter(object sender, DragEventArgs e)
        {
         
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        #endregion
        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if (e.RowIndex >= 0)
            //{
            //    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
            //    selected.Text = row.Cells[0].Value.ToString();
            //}
            int idx = dataGridView1.CurrentCell.RowIndex;
            selected.Text = dt_student.Rows[idx][4].ToString();
            string choosed_t = dt_student.Rows[idx]["studentmaster"].ToString();


            if (this.choice == 1)
                m_group.c1 = choosed_t;
            else if (this.choice == 2)
                m_group.c2 = choosed_t;
            else if (this.choice == 3)
                m_group.c3 = choosed_t;
            else if (this.choice == 4)
                m_group.c4 = choosed_t;
            else if (this.choice == 5)
                m_group.c5 = choosed_t;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            selected = textBox1;
            choice = 1;
            radioButton1.Checked = true;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            selected = textBox2;
            choice = 2;
            radioButton2.Checked = true;
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            selected = textBox3;
            choice = 3;
            radioButton3.Checked = true;
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            selected = textBox4;
            choice = 4;
            radioButton4.Checked = true;
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            selected = textBox5;
            choice = 5;
            radioButton5.Checked = true;
        }
    }
}
