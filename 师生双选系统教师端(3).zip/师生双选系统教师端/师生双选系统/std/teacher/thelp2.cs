﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace teacher
{
   public class thelp2
    {
        public static string grade;
        public static string profession;
    }
}
