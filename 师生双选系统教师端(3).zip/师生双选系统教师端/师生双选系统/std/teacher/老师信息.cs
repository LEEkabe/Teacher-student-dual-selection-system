﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class 老师信息 : UserControl
    {
       
        public 老师信息()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!=""&& textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "" && textBox8.Text != "" && textBox9.Text != "" && richTextBox1.Text!="")
            {
                Model.User model = new Model.User();
                model.name = textBox1.Text.Trim();
                model.id = textBox2.Text.Trim();
                model.sex = textBox3.Text.Trim();
                model.year= textBox4.Text.Trim();
                model.academy = textBox5.Text.Trim();
                model.profession= textBox6.Text.Trim();
                model.grade= textBox7.Text.Trim();
                model.jobtitle = textBox8.Text.Trim();
                model.phone= textBox9.Text.Trim();
                model.userName = thelp.username;
                model.major = richTextBox1.Text.Trim();
              
                BLL.修改 user = new BLL.修改();
                if(user.Updateteacher(model))
                {
                    MessageBox.Show("信息更新成功");
                }
                else
                    {
                    MessageBox.Show("信息更新失败，请再次修改");
                }               
            }
            else
            {
                MessageBox.Show("信息请不要为空");
            }
        }

        private void t2_Load(object sender, EventArgs e)
        {
            BLL.User bll = new BLL.User();
            Model.User model = bll.GetMore(thelp.username);
            
            
            if (model == null)
            {
                MessageBox.Show("数据查询出错");
                return;
            }
            else
            {
               
                textBox1.Text = model.name.Trim();
                textBox2.Text = model.id.Trim();
                textBox3.Text = model.sex.Trim();
                textBox4.Text = model.year.Trim();
                textBox5.Text = model.academy.Trim();
                textBox6.Text = model.profession.Trim();
                textBox7.Text = model.grade.Trim();
                textBox8.Text = model.jobtitle.Trim();
                textBox9.Text = model.phone.Trim();
                richTextBox1.Text = model.major.Trim();
            }
               
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
