﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class 主界面 : Form
    {
        private string id;
        
        public 主界面(string id)
        {
            this.id = id;
            InitializeComponent();
        }
        public void addwind(Control c)
        {
            c.Dock = DockStyle.Fill;
            panel5.Controls.Clear();
            panel5.Controls.Add(c);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            通知界面 t1 = new 通知界面();
            addwind(t1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            老师信息 t2 = new 老师信息();
            addwind(t2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            t3 t3 = new t3();
            addwind(t3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            学生信息查询 t4 = new 学生信息查询();
            addwind(t4);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            老师选择 t5 = new 老师选择();
            addwind(t5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            最终结果显示 t6 = new 最终结果显示();
            addwind(t6);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            联系管理员 t7 = new 联系管理员();
            addwind(t7);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            忘记密码 t8 = new 忘记密码();
            addwind(t8);
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
          
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
             
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            信息 i= new 信息(); 
            i.ShowDialog();
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            登录界面 login = new 登录界面();
            login.ShowDialog();
        }
        private Point mouseOff;//鼠标移动位置变量
        private bool leftFlag;
        private void panel5_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void panel5_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void panel5_MouseMove(object sender, MouseEventArgs e)
        {
           
        }
        #region
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        
        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseOff = new Point(-e.X, -e.Y); //得到变量的值
                leftFlag = true;                  //点击左键按下时标注为true;
            }
        }

        private void tlogin1_Load(object sender, EventArgs e)
        {
            this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
            this.Top = Screen.PrimaryScreen.Bounds.Height / 2 - this.Height / 2;//桌面的高度的一半减去自身高度的一半

        }
#endregion
        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
 if (leftFlag)
            {
                Point mouseSet = Control.MousePosition;
                mouseSet.Offset(mouseOff.X, mouseOff.Y);  //设置移动后的位置
                Location = mouseSet;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
if (leftFlag)
            {
                leftFlag = false;//释放鼠标后标注为false;
            }
        }
    }
}
