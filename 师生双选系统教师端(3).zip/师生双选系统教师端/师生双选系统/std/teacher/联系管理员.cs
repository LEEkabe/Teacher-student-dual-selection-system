﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class 联系管理员 : UserControl
    {
        public 联系管理员()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BLL.User bll = new BLL.User();
            BLL.shou shou = new BLL.shou();

            Model.User model = bll.GetMore(thelp.username);
            Model.shou s1 = new Model.shou();

            s1.sender = model.name;
            s1.grade = model.grade;
            s1.profession = model.profession;
            s1.time = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            s1.receiver = "administrators";
            s1.messContent = richTextBox1.Text;

            if (shou.shou1(s1))
            {
                MessageBox.Show("发送成功");
                richTextBox1.Text = "";
            }

            else
                MessageBox.Show("发送失败");


        }
    }
}
