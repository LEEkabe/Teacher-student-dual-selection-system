﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace teacher
{
    public partial class 通知详情 : Form
    {
        
        public 通知详情()
        {
            InitializeComponent();
            
        }

        private void 通知详情_Load(object sender, EventArgs e)
        {
           
            label2.Text = 通知界面.str.Trim();
            label1.Text = 通知界面.str1.Trim();
            int LblNum = 通知界面.str.Length;   //Label内容长度
            int RowNum = 1000;           //每行显示的字数
            float FontWidth = label2.Width / label2.Text.Length;    //每个字符的宽度
            int RowHeight = 10;           //每行的高度
            int ColNum = (LblNum - (LblNum / RowNum) * RowNum)  + 1;   //列数
            label2.AutoSize = false;    //设置AutoSize
            label2.Width = (int)(FontWidth * 20.0);          //设置显示宽度
            label2.Height = RowHeight * ColNum;           //设置显示高度
            this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
            this.Top = Screen.PrimaryScreen.Bounds.Height / 2 - this.Height / 2;//桌面的高度的一半减去自身高度的一半

        }

        private void label1_Click(object sender, EventArgs e)
        {
           

        }
    }
}
