﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class info
    {
        public string studentgrade { get; set; }
        public string studentprofession { get; set; }
    }
}
