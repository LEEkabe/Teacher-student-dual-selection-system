﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Model
{
   public  class student
    {
        public string teamname { get; set; }
        public string teamphonenumber { get; set; }
        public string teamprofession { get; set; }
        public string teamgrade { get; set; }
        public string teamclass { get; set; }
        public string studentmaster { get; set; }
        public string studentmasterid { get; set; }
        public string studentone { get; set; }
        public string studentoneid { get; set; }
        public string studenttwo { get; set; }
        public string studenttwoid { get; set; }
        public string studentthree { get; set; }
        public string studentthreeid { get; set; }
        public string teamacademy{ get; set;}
            }
}
