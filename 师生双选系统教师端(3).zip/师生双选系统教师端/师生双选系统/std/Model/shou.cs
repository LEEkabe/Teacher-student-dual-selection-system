﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public class shou
    {
        public string sender { get; set; }
        public string grade { get; set; }
        public string profession { get; set; }
        public string time { get; set; }
        public string messContent { get; set; }              
        public string receiver { set; get; }

    }
}
