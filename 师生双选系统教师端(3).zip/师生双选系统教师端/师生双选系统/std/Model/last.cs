﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
 public  class last
    {
        public string g1 { get; set; }
        public string g2 { get; set; }

        public string g3 { get; set; }
        public string g4 { get; set; }
        public string g5 { get; set; }

        public string master { get; set; }
        public string teamname { get; set; }
    }
}
