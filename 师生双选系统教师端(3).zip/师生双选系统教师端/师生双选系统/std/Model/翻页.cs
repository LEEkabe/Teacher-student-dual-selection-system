﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class 翻页
    {
        public int pageCount { set; get; }
        public int pageSize { set; get; }
        public int pageIndex { set; get; }
        public int recordCount { set; get; }
    }
}
