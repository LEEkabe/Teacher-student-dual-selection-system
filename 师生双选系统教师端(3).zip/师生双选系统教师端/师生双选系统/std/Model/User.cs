﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class User
    {   
        //登录
        #region namepwd

        public string userName { get; set; }
        public string userPassword { get; set; }
        #endregion
        //导师个人信息
        #region teacher information
        public string id { get; set; }
        public string year { get; set; }
        public string name { get; set; }
        public string sex { get; set; }
        public string profession { get; set; }
        public string phone { get; set; }
        public string academy { get; set; }
        public string grade { get; set; }
        public string major { get; set; }
        public string jobtitle { get; set; }
        #endregion
        
    }
}
