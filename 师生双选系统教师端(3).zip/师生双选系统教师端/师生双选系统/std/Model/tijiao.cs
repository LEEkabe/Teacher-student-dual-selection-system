﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public class tijiao
    {
        public string name { get; set; }
        public string id { get; set; }
        public string profession { get; set; }
        public string grade { get; set; }
        public string d1 { get; set; }
        public string d1id { get; set; }
        public string d2 { get; set; }
        public string d2id { get; set; }
        public string d3 { get; set; }
        public string d3id { get; set; }
        public string d4 { get; set; }
        public string d4id { get; set; }
        public string d5 { get; set; }
        public string d5id { get; set; }
        public string count { get; set; }
        public string count1 { get; set; }
        public string studentmasterid { get; set; }
        public string ddl { get; set; }
        public string start { get; set; }


    }
}
