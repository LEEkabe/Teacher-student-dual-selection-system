﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class stdsInfor
    {
        public DataTable GetList()
        {
            string sql = string.Format("select * from [5_8_student] where studentgrade='{0}'",Model.stuInfor.studentgrade);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            return dt;
        }
        
        public DataTable Find()
        {
            DataTable dt = new DataTable();
            if(Model.stdfind.stdacademy!=null&&Model.stdfind.stdclass==null)
            {
                string find1 = string.Format("select * from [5_8_student] where studentacademy='{0}' and studentgrade='{1}'", Model.stdfind.stdacademy, Model.stuInfor.studentgrade);
                 dt = sqlDBhelper.ExecuteDataTable(find1);
                return dt;
            }
            if(Model.stdfind.stdacademy == null && Model.stdfind.stdclass != null)
            {
                string find2= string.Format("select * from [5_8_student] where studentclass='{0}' and studentgrade='{1}'", Model.stdfind.stdclass, Model.stuInfor.studentgrade);
                 dt = sqlDBhelper.ExecuteDataTable(find2);
                return dt;
            }
            if (Model.stdfind.stdacademy != null && Model.stdfind.stdclass != null)
            {
                string find3 = string.Format("select * from [5_8_student] where studentacademy='{0}' and studentgrade='{1}' and studentclass='{2}'", Model.stdfind.stdacademy, Model.stuInfor.studentgrade, Model.stdfind.stdclass);
                 dt = sqlDBhelper.ExecuteDataTable(find3);
                return dt;
            }
            else
                return GetList();
        }

    }
}
