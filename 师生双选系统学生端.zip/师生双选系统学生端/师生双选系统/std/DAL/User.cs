﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class User
    {
        public int Login(Model.User m_user)
        {
            int res = -1;
            string sql = string.Format("select * from [5_8_Login] where uid='{0}' and pwd='{1}'",m_user.Id,m_user.Pwd);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            if(dt.Rows.Count>0)
            {
                Model.loginfo.Name = dt.Rows[0][1].ToString();
                Model.loginfo.Id = dt.Rows[0][0].ToString();
                Model.stdhelp.username = Model.loginfo.Name;
                Model.stdhelp.pwd = m_user.Pwd;               
                stuInfor();
                res = 0;
            }
            else
            {
                res = 1;
            }
          
            return res;
        }

        public void stuInfor()//学生信息
        {


            string sql = string.Format("select * from [5_8_student] where studentname='{0}'", Model.loginfo.Name);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            if (dt.Rows.Count > 0)
            {
                Model.stuInfor.studentname = dt.Rows[0][0].ToString();
                Model.stuInfor.studentid = dt.Rows[0][1].ToString();
                Model.stuInfor.studentclass = dt.Rows[0][2].ToString();
                Model.stuInfor.studentprofession = dt.Rows[0][3].ToString();
                Model.stuInfor.studentacademy = dt.Rows[0][4].ToString();
                Model.stuInfor.studentgrade = dt.Rows[0][5].ToString();
                Model.stuInfor.studentnumber = dt.Rows[0][6].ToString();
                Model.stuInfor.studentsex = dt.Rows[0][7].ToString();
                Model.stuInfor.studentage = dt.Rows[0][8].ToString();
                Model.stuInfor.studentpolitical = dt.Rows[0][9].ToString();
            }
            Model.stdhelp.grade = Model.stuInfor.studentgrade;
            Model.stdhelp.profession = Model.stuInfor.studentprofession;
        }

        public bool Update(Model.User model)//修改密码
        {


            string strSql = string.Format("update [5_8_Login] set pwd=@pwd where name='{0}'",Model.stdhelp.username);


            SqlParameter[] parameters = {
                                       
                                       new SqlParameter("@pwd", SqlDbType.VarChar,30),
            };
            
            parameters[0].Value = model.Pwd;
            int row = sqlDBhelper.ExecuteNonQuery(strSql, CommandType.Text, parameters);

            if (row == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }





    }
  }
