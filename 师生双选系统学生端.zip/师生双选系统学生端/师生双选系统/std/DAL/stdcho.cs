﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class stdcho
    {
        public Model.a Getlast()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select teamname from [5_8_team] where studentmaster=@name");

            SqlParameter[] parameters = {
                    new SqlParameter("@name", SqlDbType.Char,30) };
            parameters[0].Value = Model.stuInfor.studentname;
            Model.a model = new Model.a();
            DataTable data = sqlDBhelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);          
                model.teamname = data.Rows[0][0].ToString();
                return model;                        
        }
       
        public int Getlast1()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(*) from [5_8_group]");

            int data = (int)sqlDBhelper.ExecuteScalar(strSql.ToString(), CommandType.Text);
            data = data + 1;
            
             
            return data;
            
        }
        public int Add()
        {
            StringBuilder strSql = new StringBuilder();
            SqlParameter[] parameters;
            strSql.Append("insert into [5_8_group](g_id,teamname,grade,profession,class,master,c1,c2,c3) values(@g_id,@teamname,@grade,@profession,@class,@master,@c1,@c2,@c3)");
            parameters = new SqlParameter[] {
                new SqlParameter("@g_id", SqlDbType.Int),
                new SqlParameter("@teamname", SqlDbType.NVarChar),
                new SqlParameter("@grade", SqlDbType.NVarChar),
                new SqlParameter("@profession", SqlDbType.NVarChar),
                new SqlParameter("@class", SqlDbType.NVarChar),
                new SqlParameter("@master", SqlDbType.NVarChar),
                new SqlParameter("@c1", SqlDbType.NVarChar),
                 new SqlParameter("@c2", SqlDbType.NVarChar),
                new SqlParameter("@c3", SqlDbType.NVarChar)
            };
            Model.a c = Getlast();
           int a = Getlast1();
            Model.a h = new Model.a();
            h.teamid = Convert.ToString(a);
           
            parameters[1].Value = c.teamname;
            parameters[0].Value = h.teamid;
            parameters[2].Value = Model.stuInfor.studentgrade;
            parameters[3].Value = Model.stuInfor.studentprofession;
            parameters[4].Value = Model.stuInfor.studentclass;
            parameters[5].Value = Model.stuInfor.studentname;
            parameters[6].Value = Model.stucho.teaoneid;
            parameters[7].Value = Model.stucho.teatwoid;
            parameters[8].Value = Model.stucho.teathreeid;
            int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
            if (rows > 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}
