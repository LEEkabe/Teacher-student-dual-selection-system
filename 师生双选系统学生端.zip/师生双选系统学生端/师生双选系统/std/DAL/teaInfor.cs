﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class teaInfor
    {
       
        public DataTable getInfor()
        {

            string sql = string.Format("select * from [ateacher]");
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            return dt;
        }

        public DataTable Find()
        {
            DataTable dt = new DataTable();
            if (Model.teafind.teaacademy != null && Model.teafind.teaprofession == null)
            {
                string find1 = string.Format("select * from [ateacher] where academy='{0}' and grade='{1}'", Model.teafind.teaacademy, Model.stuInfor.studentgrade);
                dt = sqlDBhelper.ExecuteDataTable(find1);
                return dt;
            }
            if (Model.teafind.teaacademy == null && Model.teafind.teaprofession != null)
            {
                string find2 = string.Format("select * from [ateacher] where profession='{0}' and grade='{1}'", Model.teafind.teaprofession, Model.stuInfor.studentgrade);
                dt = sqlDBhelper.ExecuteDataTable(find2);
                return dt;
            }
            if (Model.teafind.teaacademy != null && Model.teafind.teaprofession != null)
            {
                string find3 = string.Format("select * from [ateacher] where academy='{0}' and grade='{1}' and profession='{2}'", Model.teafind.teaacademy, Model.stuInfor.studentgrade, Model.teafind.teaprofession);
                dt = sqlDBhelper.ExecuteDataTable(find3);
                return dt;
            }
            else
                return getInfor();
        }
    }
}
