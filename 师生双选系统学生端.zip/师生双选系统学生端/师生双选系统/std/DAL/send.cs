﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class send
    {
        public int Sendmess(Model.stdsend send)
        {
            StringBuilder strSql = new StringBuilder();
            SqlParameter[] parameters;
            strSql.Append("insert into [5_8_send](sender,grade,profession,time,messcontent,receiver) values(@sender,@grade,@profession,@time,@messcontent,@receiver)");
            parameters = new SqlParameter[] {
                new SqlParameter("@sender", SqlDbType.NVarChar),
                new SqlParameter("@grade",SqlDbType.NVarChar),
                new SqlParameter("@profession",SqlDbType.NVarChar),
               new SqlParameter("@time", SqlDbType.NVarChar),
                new SqlParameter("@messcontent",SqlDbType.NVarChar),
                new SqlParameter("@receiver",SqlDbType.NVarChar), };
            parameters[0].Value = send.sender;
            parameters[1].Value = send.grade;
            parameters[2].Value = send.profession;
            parameters[3].Value = send.time;
            parameters[4].Value = send.messContent;
            parameters[5].Value = send.receiver;
            int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
            if (rows > 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}
