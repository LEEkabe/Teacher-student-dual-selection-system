﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class stdteam
    {
        public int Add()
        {
          
            StringBuilder strSql = new StringBuilder();
            SqlParameter[] parameters;
            strSql.Append("select count(*) from [5_8_team] where teamgrade=@grade");
            parameters = new SqlParameter[] {
                    new SqlParameter("@grade", SqlDbType.Int)};
            parameters[0].Value = Model.stuInfor.studentgrade;
            
            int group_count = (int)sqlDBhelper.ExecuteScalar(strSql.ToString(), CommandType.Text, parameters);
            group_count++;
            Model.stdteam.teamid = Convert.ToInt32(group_count);
            strSql.Clear();



            strSql.Append("insert into [5_8_team](teamname,teamprofession,teamacademy,teamgrade,studentmaster,studentmasterid,studentone,studenttwo,studentthree,teamphonenumber,g_id) values(@teamname,@teamprofession,@teamacademy,@teamgrade,@studentmaster,@studentmasterid,@studentone,@studenttwo,@studentthree,@teamphonenumber,@g_id)");
            parameters = new SqlParameter[] {
                new SqlParameter("@teamname", SqlDbType.NVarChar),
                new SqlParameter("@teamprofession",SqlDbType.NVarChar),
                new SqlParameter("@teamacademy",SqlDbType.NVarChar),
                new SqlParameter("@teamgrade", SqlDbType.NVarChar),
                new SqlParameter("@studentmaster", SqlDbType.NVarChar),
                new SqlParameter("@studentmasterid", SqlDbType.NVarChar),
                new SqlParameter("@studentone", SqlDbType.NVarChar),
                
                new SqlParameter("@studenttwo", SqlDbType.NVarChar),
                
                new SqlParameter("@studentthree", SqlDbType.NVarChar),
               
                new SqlParameter("@teamphonenumber", SqlDbType.NVarChar),
               new SqlParameter("@g_id", SqlDbType.NVarChar)
            };
            parameters[0].Value = Model.teamwork.teamname;
            parameters[1].Value = Model.stuInfor.studentprofession;
            parameters[2].Value = Model.stuInfor.studentacademy;
            parameters[3].Value = Model.stuInfor.studentgrade;
            parameters[4].Value = Model.stdteam.studentmaster;
            parameters[5].Value = Model.stuInfor.studentid;
            parameters[6].Value = Model.stdteam.studentone;
            
            parameters[7].Value = Model.stdteam.studenttwo;
           
            parameters[8].Value = Model.stdteam.studentthree;
           
            parameters[9].Value = Model.stuInfor.studentnumber;
            parameters[10].Value = Model.stdteam.teamid;
            int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
            if (rows > 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
            
        }

        public int change()
        {
            StringBuilder strSql = new StringBuilder();
            SqlParameter[] parameters = {
                    new SqlParameter("@studentone", SqlDbType.NVarChar),
                    new SqlParameter("@studenttwo", SqlDbType.NVarChar),
                    new SqlParameter("@studentthree", SqlDbType.NVarChar),
                    new SqlParameter("@studentmaster", SqlDbType.NVarChar)
                };
            parameters[0].Value = Model.stdupdate.studentone;
            parameters[1].Value = Model.stdupdate.studenttwo;
            parameters[2].Value = Model.stdupdate.studentthree;
            parameters[3].Value = Model.stdteam.studentmaster;
            if(Model.stdupdate.studentone!=Model.stdteam.studentone)
            {
                strSql.Append("update [5_8_team] set studentone=@studentone where studentmaster=@studentmaster");
                int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            if(Model.stdupdate.studenttwo!=Model.stdteam.studenttwo)
            {
                strSql.Append("update [5_8_team] set studenttwo=@studenttwo where studentmaster=@studentmaster");
                int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            if (Model.stdteam.studentthree != Model.stdupdate.studentthree)
            {
                strSql.Append("update [5_8_team] set studentthree=@studentthree where studentmaster=@studentmaster");
                int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
                return -2;
        }
        public DataTable Show()
        {
            string sql = string.Format("select * from [5_8_team] where teamgrade='{0}'", Model.stuInfor.studentgrade);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            return dt;
        }
        
        public int addteam()
        {
            string sql = string.Format("select * from [5_8_team] where teamname='{0}'",Model.teamselect.selectedteam);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            if(dt.Rows[0][7].ToString()=="")
            {
                string sql1 = string.Format("update [5_8_team] set studentone='{0}' where teamname='{1}'",Model.stuInfor.studentname,Model.teamselect.selectedteam);
                int rows = sqlDBhelper.ExecuteNonQuery(sql1);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            if (dt.Rows[0][9].ToString() == "")
            {
                string sql2 = string.Format("update [5_8_team] set studenttwo='{0}' where teamname='{1}'", Model.stuInfor.studentname, Model.teamselect.selectedteam);
                int rows = sqlDBhelper.ExecuteNonQuery(sql2);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            if (dt.Rows[0][11].ToString() == "")
            {
                string sql3 = string.Format("update [5_8_team] set studentthree='{0}' where teamname='{1}'", Model.stuInfor.studentname, Model.teamselect.selectedteam);
                int rows = sqlDBhelper.ExecuteNonQuery(sql3);
                if (rows > 0)
                {

                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
                return -2;
        }
    }
}
