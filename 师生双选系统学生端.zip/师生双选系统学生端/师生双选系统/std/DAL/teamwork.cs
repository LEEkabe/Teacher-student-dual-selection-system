﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class teamwork
    {
        public int Add()
        {
            StringBuilder strSql = new StringBuilder();
            SqlParameter[] parameters;
            strSql.Append("insert into [5_8_teamwork](teamname,introduction,key_word) values(@teamname,@introduction,@key_word)");
            parameters = new SqlParameter[] {
                new SqlParameter("@teamname", SqlDbType.NVarChar),
                new SqlParameter("@introduction",SqlDbType.NVarChar),
                new SqlParameter("@key_word",SqlDbType.NVarChar)};
            parameters[0].Value = Model.teamwork.teamname;
            parameters[1].Value = Model.teamwork.intro;
            parameters[2].Value = Model.teamwork.keyword;
            int rows = sqlDBhelper.ExecuteNonQuery(strSql.ToString(), CommandType.Text, parameters);
            if (rows > 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}
