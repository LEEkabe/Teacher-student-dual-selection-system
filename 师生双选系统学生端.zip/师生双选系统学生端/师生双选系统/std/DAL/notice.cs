﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public  class notice
    {
        public void GetNotice(Model.notice notice)
        {
            string sql = string.Format("select * from [5_8_send] where receiver='学生' and grade='{0}' and profession='{1}'",Model.stdhelp.grade,Model.stdhelp.grade);
            DataTable dt = sqlDBhelper.ExecuteDataTable(sql);
            if(dt.Rows.Count>0)
            {
                notice.noticecontent = dt.Rows[0][6].ToString();
                notice.sender = dt.Rows[0][2].ToString();
                notice.time = dt.Rows[0][5].ToString();
            }
        }
    }
}
