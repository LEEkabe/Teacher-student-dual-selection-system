﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class teamwork
    {
        public static string teamname;
        public static string intro;
        public static string keyword;
    }
}
