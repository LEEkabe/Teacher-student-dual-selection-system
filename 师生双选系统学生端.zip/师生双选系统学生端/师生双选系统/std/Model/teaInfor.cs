﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class teaInfor
    {
        public  string name { get; set; }//教师姓名
        public  string sex { get; set; }//教师性别
        public  string jobtitle { get; set; }//教师职称
        public  string profession { get; set; }//教师所在专业
        public  string academy { get; set; }//教师所在学院
        public  string phone { get; set; }//教师电话
        public  string major { get; set; }//教师擅长领域
        public  int groupboxnum { get; set; }//groupbox的数量


    }
}
