﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class notice
    {
        public string noticecontent { get; set; }
        public string sender { get; set; }
        public string time { get; set; }
    }
}
