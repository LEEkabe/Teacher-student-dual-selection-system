﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class stuInfor
    {
        public static string studentname { get; set; }//学生姓名
        public static string studentid { get; set; }//学号
        public static string studentclass { get; set; }//班级
        public static string studentprofession { get; set; }//专业
        public static string studentacademy { get; set; }//学院
        public static string studentgrade { get; set; }//年级
        public static string studentnumber { get; set; }//电话
        public static string studentsex { get; set; }//性别
        public static string studentage { get; set; }//年龄
        public static string studentpolitical { get; set; }//政治面貌
    }
}
