﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class stucho
    {
        public static string teaoneid;
        public static string teatwoid;
        public static string teathreeid;
    }
}
