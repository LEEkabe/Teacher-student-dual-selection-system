﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public class stdhelp
    {
        public static string username;
        public static string pwd;
        public static string grade;
        public static string profession;
    }
}
