﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class join : Form
    {
        DataTable team= new DataTable();
        DAL.stdteam stdteam = new DAL.stdteam();
        public join()
        {
            InitializeComponent();
            team = stdteam.Show();
            dataGridView1.DataSource = team;
        }
        private void dataGridView1_MouseClick(Object sender, MouseEventArgs e)
        {
            int idx = dataGridView1.CurrentCell.RowIndex;

            Model.teamselect.selectedteam = team.Rows[idx]["teamname"].ToString();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DAL.stdteam stdteam = new DAL.stdteam();
            int row = stdteam.addteam();
            if (row == 0)
                MessageBox.Show("加入成功！");
            if (row == -1)
                MessageBox.Show("该组已满员，请重新选择！");
            else
                MessageBox.Show("加入失败，请重新选择！");
        }
    }
}
