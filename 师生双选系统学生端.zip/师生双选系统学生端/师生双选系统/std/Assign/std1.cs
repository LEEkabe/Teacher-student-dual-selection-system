﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std1 : UserControl
    {
        public std1()
        {
            InitializeComponent();
            textBox2.Text = Model.stuInfor.studentname;
            textBox8.Text = Model.stuInfor.studentid;
            textBox4.Text = Model.stuInfor.studentsex;
            textBox5.Text = Model.stuInfor.studentage;
            textBox1.Text = Model.stuInfor.studentgrade;
            textBox6.Text = Model.stuInfor.studentacademy;
            textBox9.Text = Model.stuInfor.studentprofession;
            textBox7.Text = Model.stuInfor.studentclass;
            textBox10.Text = Model.stuInfor.studentpolitical;
            textBox3.Text = Model.stuInfor.studentnumber;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
