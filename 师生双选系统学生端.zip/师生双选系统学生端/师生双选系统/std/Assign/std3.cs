﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std3 : UserControl
    {
        public std3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            choice cho = new choice();
            cho.ShowDialog();
            textBox3.Text = Model.choteacher.Name;
            Teacheck();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            choice cho = new choice();
            cho.ShowDialog();
            textBox4.Text = Model.choteacher.Name;
            Teacheck();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            choice cho = new choice();
            cho.ShowDialog();
            textBox5.Text = Model.choteacher.Name;
            Teacheck();
        }

        public void Teacheck()
        {
            if (textBox3.Text != "")
            {
                if (textBox3.Text == textBox4.Text || textBox3.Text == textBox5.Text)
                    MessageBox.Show("导师重复选择，请重新选择！");

            }
            if (textBox4.Text != "")
            {
                if (textBox4.Text == textBox3.Text || textBox5.Text == textBox4.Text)
                    MessageBox.Show("导师重复选择，请重新选择！");

            }
            if (textBox5.Text != "")
            {
                if (textBox4.Text == textBox5.Text || textBox5.Text == textBox3.Text)
                    MessageBox.Show("导师重复选择，请重新选择！");

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            if(textBox3.Text==""&&textBox4.Text==""&&textBox5.Text=="")
            {
                MessageBox.Show("未选择导师，请选择！");
            }
            if(textBox3.Text!="")
            {
                Model.stucho.teaoneid = textBox3.Text;
            }
            if (textBox4.Text != "")
            {
                Model.stucho.teatwoid = textBox4.Text;
            }
            if (textBox5.Text != "")
            {
                Model.stucho.teathreeid = textBox5.Text;
            }
            DAL.stdcho stdcho = new DAL.stdcho();
            int row = stdcho.Add();
            if (row == 0)
            {
                MessageBox.Show("队伍信息提交成功！");
            }
            else
            {
                MessageBox.Show("队伍信息提交失败！请重新提交！");
            }
        }
    }
}
