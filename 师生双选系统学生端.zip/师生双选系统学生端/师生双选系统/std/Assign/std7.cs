﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std7 : UserControl
    {
        public std7()
        {
            InitializeComponent();
           
        }

        int time = 0;

        private void std7_Load(object sender, EventArgs e)
        {
            textBox2.Text = Model.stuInfor.studentname;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            stdselect sle= new stdselect();
            sle.ShowDialog();
            textBox3.Text = Model.stdselect.selected;
            Stucheck();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            join join = new join();
            join.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            stdselect sle = new stdselect();
            sle.ShowDialog();
            textBox4.Text = Model.stdselect.selected;
            Stucheck();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            stdselect sle = new stdselect();
            sle.ShowDialog();
            textBox5.Text = Model.stdselect.selected;
            Stucheck();
        }

        public void Stucheck()
        {
            if(textBox3.Text!="")
            {
                 if (textBox3.Text == textBox4.Text||textBox3.Text==textBox5.Text)
                MessageBox.Show("队员重复选择，请重新选择！");
                 if (textBox3.Text == textBox2.Text )
                MessageBox.Show("不可以选自己！");
            }
            if(textBox4.Text!="")
            {
                if (textBox4.Text == textBox3.Text || textBox5.Text == textBox4.Text)
                    MessageBox.Show("队员重复选择，请重新选择！");
                if (textBox4.Text == textBox2.Text)
                    MessageBox.Show("不可以选自己！");
            }
            if(textBox5.Text!="")
            {
                if (textBox4.Text == textBox5.Text || textBox5.Text == textBox3.Text)
                    MessageBox.Show("队员重复选择，请重新选择！");
                if (textBox5.Text == textBox2.Text)
                    MessageBox.Show("不可以选自己！");
            }
           
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(textBox3.Text==""&&textBox4.Text==""&&textBox5.Text=="")
            {
                Model.stdteam.studentmaster = textBox2.Text;
                Model.stdteam.studentone = null;
                Model.stdteam.studenttwo = null;
                Model.stdteam.studentthree = null;
            }
            if(textBox4.Text==""&&textBox5.Text=="")
            {
                Model.stdteam.studentmaster = textBox2.Text;
                Model.stdteam.studentone = textBox3.Text;
                Model.stdteam.studenttwo = null;
                Model.stdteam.studentthree = null;
            }
            if(textBox5.Text=="")
            {
                Model.stdteam.studentmaster = textBox2.Text;
                Model.stdteam.studentone = textBox3.Text;
                Model.stdteam.studenttwo = textBox4.Text;
                Model.stdteam.studentthree = null;
            }
            if(textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                Model.stdteam.studentmaster = textBox2.Text;
                Model.stdteam.studentone = textBox3.Text;
                Model.stdteam.studenttwo = textBox4.Text;
                Model.stdteam.studentthree = textBox5.Text;
            }
            DAL.stdteam stdteam = new DAL.stdteam();
            int row = stdteam.Add();
            if(row==0)
            {
                MessageBox.Show("队伍信息提交成功！");
            }
            else
            {
                MessageBox.Show("队伍信息提交失败！请重新提交！");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
             
            if(textBox3.Text!=Model.stdteam.studentone)
            {
                Model.stdupdate.studentone = textBox3.Text;
            }
            if(textBox4.Text!=Model.stdteam.studenttwo)
            {
                Model.stdupdate.studenttwo = textBox4.Text;
            }
            if(textBox5.Text!=Model.stdteam.studentthree)
            {
                Model.stdupdate.studentthree = textBox5.Text;
            }
            DAL.stdteam stdteam = new DAL.stdteam();
            int row = stdteam.change();
            if(row==0)
            {
                time++;
                MessageBox.Show("修改成功！");
            }
            if (row == -1)
            {
                MessageBox.Show("修改失败！");
            }
            else
                MessageBox.Show("信息未修改，请重新修改！");

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            join join = new join();
            join.ShowDialog();
        }
    }
}
