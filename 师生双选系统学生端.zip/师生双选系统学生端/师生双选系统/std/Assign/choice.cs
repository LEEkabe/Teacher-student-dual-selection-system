﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class choice : Form
    {
        DataTable teas = new DataTable();
        DAL.teaInfor tea = new DAL.teaInfor();
        public choice()
        {
            InitializeComponent();

        }

        private void choice_Load(object sender, EventArgs e)
        {
            teas = tea.getInfor();
            dataGridView1.DataSource = teas;
            dataGridView1.Columns[1].Visible = false;
            dataGridView1.Columns[2].Visible = false;
            
        }

        private void dataGridView1_MouseClick(Object sender, MouseEventArgs e)
        {
            int idx = dataGridView1.CurrentCell.RowIndex;

            Model.choteacher.Name = teas.Rows[idx]["id"].ToString();
            this.Close();



        }



        private void button2_Click(object sender, EventArgs e)
        {
          //  Model.teaInfor tea = new Model.teaInfor();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Model.teaInfor tea = new Model.teaInfor();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DAL.teaInfor tea = new DAL.teaInfor();
            DataTable find = new DataTable();
            if (comboBox2.SelectedItem == null && comboBox1.SelectedItem != null)
            {
                Model.teafind.teaacademy = null;
                Model.teafind.teaprofession = comboBox1.SelectedItem.ToString();
                find = tea.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem != null && comboBox1.SelectedItem == null)
            {
                Model.teafind.teaacademy = comboBox2.SelectedItem.ToString();
                Model.teafind.teaprofession = null;
                find = tea.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem != null && comboBox1.SelectedItem != null)
            {
                Model.teafind.teaacademy = comboBox2.SelectedItem.ToString();
                Model.teafind.teaprofession = comboBox1.SelectedItem.ToString();
                find = tea.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem == null && comboBox1.SelectedItem == null)
                MessageBox.Show("请在下拉框中选择关键字！");
        }
    }
}
