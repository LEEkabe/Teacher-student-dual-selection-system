﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class stdselect : Form
    {
        DataTable stds = new DataTable();
        DAL.stdsInfor infor = new DAL.stdsInfor();
        int pageCount;
        int pageIndex=0;
        int pageSize = 10;
        public stdselect()
        {
            InitializeComponent();
            stds = infor.GetList();
            dataGridView1.DataSource = stds;
            dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].Visible = false;
        }
        

        private void dataGridView1_MouseClick(Object sender,MouseEventArgs e)
        {
            int idx = dataGridView1.CurrentCell.RowIndex;
            
                Model.stdselect.selected = stds.Rows[idx]["studentname"].ToString();
                this.Close();
           
                
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DAL.stdsInfor stds = new DAL.stdsInfor();
            DataTable find = new DataTable();
            if (comboBox2.SelectedItem == null && comboBox3.SelectedItem != null)
            {
                Model.stdfind.stdclass = comboBox3.SelectedItem.ToString();
                Model.stdfind.stdacademy = null;
                find = stds.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem != null && comboBox3.SelectedItem == null)
            {
                Model.stdfind.stdacademy = comboBox2.SelectedItem.ToString();
                Model.stdfind.stdclass = null;
                find = stds.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem != null && comboBox3.SelectedItem != null)
            {
                Model.stdfind.stdacademy = comboBox2.SelectedItem.ToString();
                Model.stdfind.stdclass = comboBox3.SelectedItem.ToString();
                find = stds.Find();
                dataGridView1.DataSource = find;
            }
            if (comboBox2.SelectedItem == null && comboBox3.SelectedItem == null)
                MessageBox.Show("请在下拉框中选择关键字！");
        }
    }
}
