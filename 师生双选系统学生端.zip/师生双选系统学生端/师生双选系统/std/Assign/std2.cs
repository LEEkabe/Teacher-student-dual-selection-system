﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std2 : UserControl
    {
        public std2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DAL.teamwork tw = new DAL.teamwork();
            
            
           Model.teamwork.teamname = textBox1.Text;
            Model.teamwork.intro = richTextBox1.Text;
            Model.teamwork.keyword = textBox2.Text;
            int row = tw.Add();
            if (textBox1.Text == null)
                MessageBox.Show("请输入您的课设题目！");
            if (row == 0)
                MessageBox.Show("提交成功！");
            if (row == -1)
                MessageBox.Show("提交失败！");
        }
    }
}
