﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class main : Form
    {
        int panelwhite;
        bool panelwitch;
        
        public void addwind(Control c)
        {
            c.Dock = DockStyle.Fill;
            panel5.Controls.Clear();
            panel5.Controls.Add(c);

        }
        public main()
        {
            InitializeComponent();
            panelwhite = panel1.Width;
            panelwitch = false;
            linkLabel2.Text = Model.loginfo.Name;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            login login = new login();
            login.ShowDialog();
        }

        private void login1_Load(object sender, EventArgs e)
        {

        }
        private void panelDH()//控制panel1没做出来
        {
            if(panelwitch)
            {
                panel1.Width = panel1.Width + 10;

                if(panel1.Width<=panelwhite)
                {
                    panelwitch = false;
                }
            }
            else
            {
                panel1.Width = panel1.Width - 10;
                if(panel1.Width<67)
                {
                    panelwitch = true;
                    timer1.Stop();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panelDH();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            std6 std6 = new std6();
            addwind(std6);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            std1 std1 = new std1();
            addwind(std1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            std2 std2 = new std2();
            addwind(std2);
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            std3 std3 = new std3();
            addwind(std3);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            std4 std4 = new std4();
            addwind(std4);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            std5 std5 = new std5();
            addwind(std5);
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            std8 std8 = new std8();
            addwind(std8);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            std7 std7 = new std7();
            addwind(std7);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Visible = false;
            login login = new login();
            login.ShowDialog();

        }

        
    }
}
