﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std5 : UserControl
    {
        public std5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Model.stdsend send = new Model.stdsend();
            send.sender = Model.stdhelp.username;
            send.receiver = "administrators";
            send.time= DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            send.grade = Model.stdhelp.grade;
            send.profession = Model.stdhelp.profession;
            send.messContent = richTextBox1.Text;
            DAL.send send1 = new DAL.send();
            if (send1.Sendmess(send) == 0)
                MessageBox.Show("提交成功！请等待管理员联系。");
            else
                MessageBox.Show("提交失败！请重新提交！");
        }
    }
}
