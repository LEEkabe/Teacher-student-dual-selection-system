﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class std8 : UserControl
    {
        public std8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            if (textBox1.Text.Trim() != Model.stdhelp.pwd)
            {
                MessageBox.Show("原密码错误");


                return;
            }
            if (textBox2.Text.Trim() == "")
            {
                MessageBox.Show("新密码不能为空");
                textBox2.Focus();
                return;
            }
            if (textBox4.Text.Trim() != textBox2.Text)
            {
                MessageBox.Show("密码不一致，请重新输入");
                textBox4.Focus();


                return;
            }
            if (textBox4.Text == "")
            {
                MessageBox.Show("密码不能为空！");
            }


            else
            {
                Model.User model = new Model.User();
                DAL.User use = new DAL.User();
                model.Pwd = textBox2.Text.Trim();


                if (use.Update(model))
                {


                    MessageBox.Show("密码更新成功！");
                    Application.Restart();
                }
                else
                {
                    MessageBox.Show("密码更新失败！");
                }
            }
        }
    }
}
