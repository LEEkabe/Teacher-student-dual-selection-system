﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string uid = textBox1.Text;
            string pwd = textBox2.Text;

            if(uid=="admin"&&pwd=="123")
            {
                showWindows();
            }
            else if(uid!=null&&pwd!=null)
            {
                Model.User m_user = new Model.User();
                m_user.Id = uid;
                m_user.Pwd = pwd;

                BLL.User b_user = new BLL.User();
                int res = b_user.Login(m_user);
                if(res==0)
                {
                    showWindows();
                }
                else if(res==1)
                {
                    MessageBox.Show("用户名或密码不对！");
                }
            }
            else if(uid==null||pwd==null)
            {
                MessageBox.Show("请输入用户名和密码！");
            }
           
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void showWindows()
        {
            this.Visible = false;
            main m = new main();
            m.ShowDialog();
            
        }
    }
}
