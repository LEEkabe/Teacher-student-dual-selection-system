﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class GetinStu
    {
        public DataTable select()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [5_8_student]");
            return res;
        }

        public DataTable printgroup()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select teamname,teamprofession,teamacademy,teamgrade,studentone,studenttwo,studentthree from [5_8_team]");
            return res;
        }
        public DataTable selectg()
        {

            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select g_id,c1,c2,c3,grade,profession from [5_8_group]");
            return res;
        }
        public DataTable fenpeig(Model.fenpei fp)
        {
            string sql = "select g_id,c1,c2,c3,t from [5_8_group] where grade=@grade and profession=@pro";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@grade", fp.grade);
            sps[1] = new SqlParameter("@pro", fp.profession);
            //sps[1] = new SqlParameter("@studentprofession", studentinfo.studentprofession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public bool updateg(DataTable g) 
        {
            bool res;
            res = SqlDbHelper.update_Table(g, "[5_8_g]");
            return res;
        }

        public bool ups(DataTable s)
        {
            bool res;
            res = SqlDbHelper.update_Table(s, "[5_8_student]");
            return res;
        }
        public bool upst(DataTable s)
        {
            bool res;
            res = SqlDbHelper.update_Table(s, "[5_8_student]");
            return res;
        }
        public DataTable getList()
        {
            string sql = string.Format("select * from [5_8_student]");
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql);
            return dt;
        }
        public bool updateList(DataTable dt)
        {
            bool res;
            res = SqlDbHelper.update_Table(dt, "[5_8_student]");
            return true;            //更新指定的表
        }
        public DataTable Getstudent(Model.stu studentinfo)
        {
            string sql = "Select * from [5_8_group] where grade=@studentgrade and profession=@studentprofession ";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@studentgrade ", studentinfo.studentgrade);
            sps[1] = new SqlParameter("@studentprofession", studentinfo.studentprofession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getstudenta(Model.stu studentinfo)
        {
            string sql = "Select * from [5_8_group] where grade=@studentgrade";
            SqlParameter[] sps = new SqlParameter[1];
            sps[0] = new SqlParameter("@studentgrade ", studentinfo.studentgrade);
            //sps[1] = new SqlParameter("@studentprofession", studentinfo.studentprofession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getstudentb(Model.stu studentinfo)
        {
            string sql = "Select * from [5_8_group] where profession=@studentprofession ";
            SqlParameter[] sps = new SqlParameter[1];
            //sps[0] = new SqlParameter("@studentgrade ", studentinfo.studentgrade);
            sps[0] = new SqlParameter("@studentprofession", studentinfo.studentprofession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }

        public DataTable Getstudentc(Model.stu studentinfo)
        {
            string sql = string.Format("select * from [5_8_student]");
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql);
            return dt;
        }

        public bool addstudent(Model.stu stu)
        {
            //DAL.messTable messT = new DAL.messTable();
            //bool mT = messT.messTrue(table);

            string sql = string.Format("insert into [5_8_student](studentname,studentid,studentprofession,studentgrade,studentnumber) values(@studentname,@studentid,@studentprofession,@studentgrade,@studentnumber)");
            SqlParameter[] d_sps = new SqlParameter[5];
            d_sps[0] = new SqlParameter("@studentname", stu.studentname);
            d_sps[1] = new SqlParameter("@studentid",stu.studentid);
            d_sps[2] = new SqlParameter("@studentprofession",stu.studentprofession);
            d_sps[3] = new SqlParameter("@studentgrade",stu.studentgrade);
            d_sps[4] = new SqlParameter("@studentnumber",stu.studentnumber);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

            return true;
        }

    }
}
