﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{


    public class User
    {

        //private string connString = @"Data Source=.;Initial Catalog=Assign;User ID=LILY-LAPTOP-JL\N\lenovo;Pwd=";
        //private SqlConnection connection;
        public void CLOSECONNECTION()
        {
            //if(connection.State == connection.Open || connection.State == connection.Broken)
            //{
            //connection.Close();
            //}
        }
        public int Login(Model.User m_user)
        {
            int res = -1;
            //using (SqlConnection con = new SqlConnection())//beiosng
            //{
            //    con.ConnectionString = "server=192.168.88.26;uid=stu;pwd=123;database=Assign";//beisong
            //    con.Open();
            //    string sql = string.Format("select * from [user] where uid='{0}' and pwd='{1}'", m_user.Id, m_user.Pwd);//表叫user
            //    SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            //    DataTable dt = new DataTable();
            //    adapter.Fill(dt);

            //    if (dt.Rows.Count > 0)
            //        res = 0;
            //    else
            //        res = 1;
            //}



            string sql = "Select * from [5_8_Login] where uid=@uid and pwd=@pwd";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@uid", m_user.Id);
            sps[1] = new SqlParameter("@pwd", m_user.Pwd);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            if (dt.Rows.Count > 0)
            {
                res = 0;
                Model.loginfo.Id = dt.Rows[0][1].ToString();
                Model.loginfo.Name = dt.Rows[0][2].ToString();
                Model.publicuser.Id= dt.Rows[0][0].ToString();
                Model.publicuser.Name = dt.Rows[0][1].ToString();
                Model.publicuser.Pwd = dt.Rows[0][2].ToString();
            }
            else
                res = 1;
            return res;
        }

        public DataTable List_user()
        {
            string sql = string.Format("select * from [5_8_student]");
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql);

            return dt;
        }

        public bool update_users(DataTable users)//更新数据表（表名）
        {
            bool res;
            res = SqlDbHelper.update_Table(users, "name");
            return true;
        }
        public bool update(Model.User user, out string msg)
        {
            string sql = "update [5_8_Login] set pwd=@pwd where uid=@id";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@id", user.Id);
            sps[1] = new SqlParameter("@pwd", user.Pwd);
            

            int res = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, sps);
            if (res == 1)
            {
                msg = "ok!";

                return true;
            }
            msg = "wrong!";
            return false;
        }
    }
}
