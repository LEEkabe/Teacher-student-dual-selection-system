﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class GetinTea
    {
        public DataTable select()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [ateacher]"); 
            return res;
        }
        public DataTable printtea()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select id,name,sex,year,academy,grade,profession,major,jobtitle from [ateacher]");
            return res;
        }
        public DataTable selectt()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select id,d1id,d2id,d3id,d4id,d5id,t_grade,t_major from [5_8_tea]");
            return res;
        }
        public DataTable fenpeig(Model.fenpei fp)
        {
            string sql = "select id,d1id,d2id,d3id,d4id,d5id,g1,g2,g3,g4,g5,res_count,t_grade,t_major from [5_8_tea] where t_grade=@grade and t_major=@pro";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@grade",fp.grade);
            sps[1] = new SqlParameter("@pro", fp.profession);
            //sps[1] = new SqlParameter("@profession", teacherinfo.profession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public bool updatet(DataTable t)
        {
            bool res;
            res = SqlDbHelper.update_Table(t, "[5_8_t]");
            return res;
        }

        public bool updatetea(DataTable t)
        {
            bool res;
            res = SqlDbHelper.update_Table(t, "[ateacher]");
            return res;
        }
        public DataTable Getteacher(Model.tea teacherinfo)
        {
            string sql = "Select * from [ateacher] where grade=@grade and profession=@profession";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@grade ", teacherinfo.grade);
            sps[1] = new SqlParameter("@profession", teacherinfo.profession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable lszy(Model.tea teacherinfo)
        {
            string sql = "select id,d1id,d2id,d3id,d4id,d5id,g1,g2,g3,g4,g5,res_count,t_grade,t_major from [5_8_tea] where grade=@grade and profession=@profession";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@grade ", teacherinfo.grade);
            sps[1] = new SqlParameter("@profession", teacherinfo.profession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getteachera(Model.tea teacherinfo)
        {
            string sql = "Select * from [ateacher] where profession=@profession";
            SqlParameter[] sps = new SqlParameter[1];
            //sps[0] = new SqlParameter("@grade ", teacherinfo.grade);
            sps[0] = new SqlParameter("@profession", teacherinfo.profession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getteacherb(Model.tea teacherinfo)
        {
            string sql = "Select * from [ateacher] where grade=@grade";
            SqlParameter[] sps = new SqlParameter[1];
            sps[0] = new SqlParameter("@grade ", teacherinfo.grade);
            //sps[1] = new SqlParameter("@profession", teacherinfo.profession);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable Getteacherc(Model.tea teacherinfo)
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [ateacher]");
            return res;
        }

        public bool updatetem(DataTable t)
        {
            string sql = "Delete from [5_8_temtable] where 1=1";
            int dt = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text);
            bool res;
            res = SqlDbHelper.update_Table(t, "[5_8_temtable]");
            return res;
        }

        public DataTable teacher()
        {
            //long[] gid = new long[7];
            string sql = "select * from [5_8_temtable]";
            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text);
            for (int i = 0; i < dt.Rows.Count; i++)//分配信息更新到教师表
            {
                string id = dt.Rows[i]["id"].ToString();
                string g1 = dt.Rows[i]["g1"].ToString();
                string g2 = dt.Rows[i]["g2"].ToString();
                string g3 = dt.Rows[i]["g3"].ToString();
                string g4 = dt.Rows[i]["g4"].ToString();
                string g5 = dt.Rows[i]["g5"].ToString();
                string count = dt.Rows[i]["res_count"].ToString();
                string sqla = "update [5_8_tea] set g1=@g1,g2=@g2,g3=@g3,g4=@g4,g5=@g5,res_count=@count where id=@id";
                SqlParameter[] sps = new SqlParameter[7];
                sps[0] = new SqlParameter("@id", id);
                sps[1] = new SqlParameter("@g1", g1);
                sps[2] = new SqlParameter("@g2", g2);
                sps[3] = new SqlParameter("@g3", g3);
                sps[4] = new SqlParameter("@g4", g4);
                sps[5] = new SqlParameter("@g5", g5);
                sps[6] = new SqlParameter("@count", count);

                int res = SqlDbHelper.ExecuteNonQuery(sqla, CommandType.Text, sps);
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 1; j < 6; j++)
                {
                    long id = Convert.ToInt64(dt.Rows[i][j]);
                    long t = Convert.ToInt64(dt.Rows[i]["id"]);
                    string sqlb = "update [5_8_group] set t=@t where g_id=@id";
                    SqlParameter[] sps = new SqlParameter[2];
                    sps[0] = new SqlParameter("@id", id);
                    sps[1] = new SqlParameter("@t", t);
                    int res = SqlDbHelper.ExecuteNonQuery(sqlb, CommandType.Text, sps);
                }
            }
            return dt;
        }

        public bool addtea(Model.tea tea)
        {
            //DAL.messTable messT = new DAL.messTable();
            //bool mT = messT.messTrue(table);

            string sql = string.Format("insert into [5_8_tea](name,id,grade,profession) values(@name,@id,@grade,@profession)");
            SqlParameter[] d_sps = new SqlParameter[4];
            d_sps[0] = new SqlParameter("@name ", tea.name);
            d_sps[1] = new SqlParameter("@grade ", tea.grade);
            d_sps[2] = new SqlParameter("@profession ",tea.profession);
            d_sps[3] = new SqlParameter("@id ", tea.id);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

            return true;
        }
        public bool addteacher(Model.tea tea)
        {
            //DAL.messTable messT = new DAL.messTable();
            //bool mT = messT.messTrue(table);

            string sql = string.Format("insert into [ateacher](name,id,grade,profession,userName,userPassword) values(@name,@id,@grade,@profession,@userName,@userPassword)");
            SqlParameter[] d_sps = new SqlParameter[6];
            d_sps[0] = new SqlParameter("@name ", tea.name);
            d_sps[1] = new SqlParameter("@grade ", tea.grade);
            d_sps[2] = new SqlParameter("@profession ", tea.profession);
            d_sps[3] = new SqlParameter("@id", tea.id);
            d_sps[4] = new SqlParameter("@userName", tea.userName);
            d_sps[5] = new SqlParameter("@userPassword", tea.userPassword);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

            return true;
        }
    }
}
