﻿ 
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class fenpei
    {
        public DataTable select()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [5_8_g]");
            return res;
        }
        public DataTable temtable()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [5_8_temtable]");
            return res;
        }

        public bool uptemtable(DataTable s)
        {
            bool res;
            res = SqlDbHelper.update_Table(s, "[5_8_temtable]");
            return res;
        }
    }
}
