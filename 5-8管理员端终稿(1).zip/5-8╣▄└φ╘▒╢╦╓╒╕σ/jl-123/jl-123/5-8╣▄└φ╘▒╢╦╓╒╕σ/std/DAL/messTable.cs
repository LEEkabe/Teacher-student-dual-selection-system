﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class messTable
    {
        public bool messTrue(Model.messTable table)
        {
            //DAL.messTable messT = new DAL.messTable();
            //bool mT = messT.messTrue(table);

            string sql = string.Format("insert into [5_8_send](title,sender,grade,profession,time,messcontent,receiver) values(@title,@sender,@grade,@profession,@time,@messcontent,@receiver)");
            SqlParameter[] d_sps = new SqlParameter[7];
            d_sps[0] = new SqlParameter("@sender ", table.sender);
            d_sps[1] = new SqlParameter("@grade ", table.grade);
            d_sps[2] = new SqlParameter("@profession ",table.profession);
            d_sps[3] = new SqlParameter("@time ", table.time);
            d_sps[4] = new SqlParameter("@title ", table.messTitle);
            d_sps[5] = new SqlParameter("@messcontent ", table.messContent);
            d_sps[6] = new SqlParameter("@receiver ", table.receiver);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, d_sps);

            return true;
        }
        public DataTable select()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [5_8_send] where receiver='管理员'");
            return res;
        }
        public DataTable selectadm()
        {
            DataTable res;
            res = SqlDbHelper.ExecuteDataTable("select * from [5_8_send] where sender='administrators'");
            return res;
        }

        public bool update(DataTable s)
        {
            bool res;
            res = SqlDbHelper.update_Table(s, "[5_8_send]");
            return res;
        }
        public int Delete(Model.messTable mess)
        {
            //Model.messTable table = new Model.messTable();
            string tm = mess.times;
            int count = 0;
            //int count = 0;
            //int g_id = model.gid;
            //int g_c1 = model.c1;
            //int g_c2 = model.c2;
            //int g_c3 = model.c3;
            string commandText = "delete from [5_8_send] where time=@time";
            SqlParameter[] parameter = new SqlParameter[1];
            parameter[0] = new SqlParameter("@time", tm);
            //parameter[0].Value = tm;

            count = SqlDbHelper.ExecuteNonQuery(commandText, CommandType.Text, parameter);

            return count;//返回执行增删改操作之后，数据库中受影响的行数
        }
    }
}