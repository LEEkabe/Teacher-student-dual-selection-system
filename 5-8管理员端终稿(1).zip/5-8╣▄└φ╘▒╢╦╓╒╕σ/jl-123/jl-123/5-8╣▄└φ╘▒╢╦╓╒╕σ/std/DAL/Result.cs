﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Result
    {
        public DataTable sstu(Model.Result result)
        {
            string sql = "Select * from [5_8_group] where profession=@profession and grade=@grade";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@profession", result.profession);
            sps[1] = new SqlParameter("@grade", result.grade);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
        public DataTable stea(Model.Result result)
        {
            string sql = "Select * from [5_8_tea] where profession=@profession and grade=@grade";
            SqlParameter[] sps = new SqlParameter[2];
            sps[0] = new SqlParameter("@profession", result.profession);
            sps[1] = new SqlParameter("@grade", result.grade);

            DataTable dt = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, sps);
            return dt;
        }
    }
}
