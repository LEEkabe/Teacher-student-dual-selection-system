﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class rule
    {
        public bool guize1(Model.rule table)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count from [5_8_rule]");
            strSql.Append(" where grade=@grade and profession=@profession"); SqlParameter[] parameters = {
                    new SqlParameter("@grade", SqlDbType.Char,30),new SqlParameter("@profession", SqlDbType.Char,30),
            };
            parameters[0].Value = table.grade;
            parameters[1].Value = table.profession;
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count == 1)
            {
                string sqr = string.Format("update [5_8_rule] set count=@count,ddl=@ddl,start=@start,leveel=@leveel,choice=@choice");


                SqlParameter[] par = {
                                            new SqlParameter("@count", SqlDbType.VarChar,11),
                                       new SqlParameter("@ddl", SqlDbType.VarChar,30),
                                       new SqlParameter("@start", SqlDbType.VarChar,30),
                                            new SqlParameter("@leveel", SqlDbType.VarChar,11),
                                            new SqlParameter("@choice", SqlDbType.VarChar,11),


            };
                par[0].Value = table.count;
                par[1].Value = table.ddl;
                par[2].Value = table.start;
                par[3].Value = table.leveel; par[4].Value = table.choice;


                int row = SqlDbHelper.ExecuteNonQuery(sqr, CommandType.Text, par);

                if (row == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                string sql = string.Format("insert into [5_8_rule](count,ddl,start,grade,profession,leveel,choice) values(@count,@ddl,@start,@grade,@profession,@leveel,@choice)");
                SqlParameter[] d_sps = new SqlParameter[5];
                d_sps[0] = new SqlParameter("@count ", table.count);
                d_sps[1] = new SqlParameter("@ddl", table.ddl);
                d_sps[2] = new SqlParameter("@start", table.start);
                d_sps[3] = new SqlParameter("@grade", table.grade);
                d_sps[4] = new SqlParameter("@profession", table.profession);
                d_sps[5] = new SqlParameter("@leveel", table.leveel);
                d_sps[6] = new SqlParameter("@choice", table.choice);
                int row = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, d_sps);
                return true;
            }
        }
        public bool guize2(Model.rule table)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select scount from [5_8_srule]");
            strSql.Append(" where grade=@grade and profession=@profession"); 
            SqlParameter[] parameters = {new SqlParameter("@grade", SqlDbType.Char,30),new SqlParameter("@profession", SqlDbType.Char,30),};
            parameters[0].Value = table.grade;
            parameters[1].Value = table.profession;
            DataTable data = SqlDbHelper.ExecuteDataTable(strSql.ToString(), CommandType.Text, parameters);
            if (data.Rows.Count == 1)
            {
                string sqr = string.Format("update [5_8_srule] set scount=@scount,sddl=@sddl,sstart=@sstart");
                SqlParameter[] par = {
                                            new SqlParameter("@scount", SqlDbType.VarChar,11),
                                       new SqlParameter("@sddl", SqlDbType.VarChar,30),
                                       new SqlParameter("@sstart", SqlDbType.VarChar,30),


            };
                par[0].Value = table.scount;
                par[1].Value = table.sddl;
                par[2].Value = table.sstart;


                int row = SqlDbHelper.ExecuteNonQuery(sqr, CommandType.Text, par);

                if (row == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                string sql = string.Format("insert into [5_8_srule](scount,sddl,sstart,grade,profession) values(@scount,@sddl,@sstart,@grade,@profession)");
                SqlParameter[] d_sps = new SqlParameter[5];
                d_sps[0] = new SqlParameter("@scount ", table.scount);
                d_sps[1] = new SqlParameter("@sddl", table.sddl);
                d_sps[2] = new SqlParameter("@sstart", table.sstart);
                d_sps[3] = new SqlParameter("@grade", table.grade);
                d_sps[4] = new SqlParameter("@profession", table.profession);
                int row = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, d_sps);
                return true;
            }
        }

    }
}
