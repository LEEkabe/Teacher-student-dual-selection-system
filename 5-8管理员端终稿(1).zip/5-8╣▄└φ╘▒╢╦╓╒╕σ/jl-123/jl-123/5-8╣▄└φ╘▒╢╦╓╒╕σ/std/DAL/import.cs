﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class import
    {
        public bool INstu(Model.stu m)
        {
            string sql = string.Format("insert into [5_8_student] values(@studentname,@studentid,@studentclass,@studentprofession,@studentacademy,@studentgrade,@studentnumber,@studentsex,@studentage,@studentpolitical)");
            SqlParameter[] d_sps = new SqlParameter[10];
            d_sps[0] = new SqlParameter("@studentname", m.studentname);
            d_sps[1] = new SqlParameter("@studentid", m.studentid);
            d_sps[2] = new SqlParameter("@studentclass", m.studentclass);
            d_sps[3] = new SqlParameter("@studentprofession", m.studentprofession);
            d_sps[4] = new SqlParameter("@studentacademy", m.studentacademy);
            d_sps[5] = new SqlParameter("@studentgrade", m.studentgrade);
            d_sps[6] = new SqlParameter("@studentnumber", m.studentnumber);
            d_sps[7] = new SqlParameter("@studentsex", m.studentsex);
            d_sps[8] = new SqlParameter("@studentage", m.studentage);
            d_sps[9] = new SqlParameter("@studentpolitical", m.studentpolitical);



            int res = SqlDbHelper.ExecuteNonQuery(sql, System.Data.CommandType.Text, d_sps);
            if (res == 1)
                return true;
            else
                return false;
        }
        public bool INtech(Model.tea m1)
        {
            string sql = string.Format("insert into [ateacher] values(@userName,@userPassword,@id,@name,@sex,@year,@academy,@grade,@profession,@major,@phone,@jobtitle)");
            SqlParameter[] d_sps = new SqlParameter[12];
            d_sps[0] = new SqlParameter("@userName", m1.userName);
            d_sps[1] = new SqlParameter("@userPassword", m1.userPassword);
            d_sps[2] = new SqlParameter("@id", m1.id);
            d_sps[3] = new SqlParameter("@name", m1.name);
            d_sps[4] = new SqlParameter("@sex", m1.sex);
            d_sps[5] = new SqlParameter("@year", m1.year);
            d_sps[6] = new SqlParameter("@academy", m1.academy);
            d_sps[7] = new SqlParameter("@grade", m1.grade);
            d_sps[8] = new SqlParameter("@profession", m1.profession);
            d_sps[9] = new SqlParameter("@major", m1.major);
            d_sps[10] = new SqlParameter("@phone", m1.phone);
            d_sps[11] = new SqlParameter("@jobtitle", m1.jobtitle);

            int res = SqlDbHelper.ExecuteNonQuery(sql, System.Data.CommandType.Text, d_sps);
            if (res == 1)
                return true;
            else
                return false;
        }
    }
}
