﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class rule
    {
        public string grade { get; set; }
        public string profession { get; set; }
        public string count { get; set; }
        public string scount { get; set; }
        public string ddl { get; set; }
        public string sddl { get; set; }
        public string start { get; set; }
        public string sstart { get; set; }
        public string leveel { get; set; }
        public string choice { get; set; }
    }
}
