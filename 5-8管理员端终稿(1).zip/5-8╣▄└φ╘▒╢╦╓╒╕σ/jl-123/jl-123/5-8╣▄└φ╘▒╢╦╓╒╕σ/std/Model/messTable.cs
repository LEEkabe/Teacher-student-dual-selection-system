﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class messTable
    {
        public string messTitle { set; get; }

        public string messContent { set; get; }
        public string sender{ set; get; }
        public string grade{ set; get; }
        public string profession { set; get; }
        public string time { set; get; }
        public string receiver { set; get; }

        public string times{ set; get; }


    }
}
