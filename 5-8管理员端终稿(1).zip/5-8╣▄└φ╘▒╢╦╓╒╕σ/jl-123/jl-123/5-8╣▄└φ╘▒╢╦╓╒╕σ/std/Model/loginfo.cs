﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class loginfo
    {
        public static string Id { get; set; }
        public static string Name { get; set; }
        public static string Pwd { get; set; }
    }
}
