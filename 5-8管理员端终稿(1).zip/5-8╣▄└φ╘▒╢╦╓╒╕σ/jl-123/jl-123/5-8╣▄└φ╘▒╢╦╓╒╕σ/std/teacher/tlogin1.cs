﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class tlogin1 : Form
    {
        public tlogin1()
        {
            InitializeComponent();
        }
        public void addwind(Control c)
        {
            c.Dock = DockStyle.Fill;
            panel5.Controls.Clear();
            panel5.Controls.Add(c);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            t1 t1 = new t1();
            addwind(t1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            t2 t2 = new t2();
            addwind(t2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            t3 t3 = new t3();
            addwind(t3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            t4 t4 = new t4();
            addwind(t4);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            t5 t5 = new t5();
            addwind(t5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            t6 t6 = new t6();
            addwind(t6);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            t7 t7 = new t7();
            addwind(t7);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            t8 t8 = new t8();
            addwind(t8);
        }
    }
}
