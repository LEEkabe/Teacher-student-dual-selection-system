﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teacher
{
    public partial class t5 : UserControl
    {
        public t5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            choice1 c1 = new choice1();
            c1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            choice1 c1 = new choice1();
            c1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            choice1 c1 = new choice1();
            c1.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            choice1 c1 = new choice1();
            c1.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            choice1 c1 = new choice1();
            c1.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
