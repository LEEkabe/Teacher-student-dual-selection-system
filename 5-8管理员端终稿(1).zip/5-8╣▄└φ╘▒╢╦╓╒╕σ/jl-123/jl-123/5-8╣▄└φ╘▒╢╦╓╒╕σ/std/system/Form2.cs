﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;

namespace system
{
    public partial class Form2 : Form
       
    {
        int index = 0;
        DataTable dt;
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dt = SqlDbHelper.ExecuteDataTable("select * from [5_8_t]");


            dataGridView1.DataSource = dt;
            printDocument1.PrintPage += new PrintPageEventHandler(printdoc_PrintPage);
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            index = 0;
            printPreviewDialog1.Document = printDocument1;

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            { printDocument1.Print(); }
                

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //开始打印
            index = 0;
            printDocument1.Print();
        }
        void printdoc_PrintPage(object sender, PrintPageEventArgs e)
        {
            int y = 120;
            Font f = new Font("宋体", 20);

            for (; index < dt.Rows.Count; index++)
            {
                e.Graphics.DrawString(dt.Rows[index][0].ToString(), f, Brushes.Black, 200, y);
                e.Graphics.DrawString(dt.Rows[index][1].ToString(), f, Brushes.Black, 400, y);
                e.Graphics.DrawString(dt.Rows[index][2].ToString(), f, Brushes.Black, 500, y);
                y += 120;
                if (y >= e.PageBounds.Height - 100)
                {
                    index++;
                    e.HasMorePages = true;
                    break;
                }
            }
        }
    }
}
