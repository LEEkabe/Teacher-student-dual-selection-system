﻿namespace system
{
    partial class printform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(printform));
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.StuBtn = new System.Windows.Forms.Button();
            this.TeamBtn = new System.Windows.Forms.Button();
            this.TeaBtn = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Location = new System.Drawing.Point(394, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 70);
            this.label1.TabIndex = 75;
            this.label1.Text = "打印中心";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.StuBtn);
            this.panel3.Controls.Add(this.TeamBtn);
            this.panel3.Controls.Add(this.TeaBtn);
            this.panel3.Location = new System.Drawing.Point(2, 11);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(996, 492);
            this.panel3.TabIndex = 74;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(757, 162);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(115, 114);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 71;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(470, 162);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 114);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 69;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(131, 162);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 68;
            this.pictureBox1.TabStop = false;
            // 
            // StuBtn
            // 
            this.StuBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.StuBtn.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StuBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.StuBtn.Location = new System.Drawing.Point(98, 345);
            this.StuBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.StuBtn.Name = "StuBtn";
            this.StuBtn.Size = new System.Drawing.Size(182, 93);
            this.StuBtn.TabIndex = 64;
            this.StuBtn.Text = "学生信息";
            this.StuBtn.UseVisualStyleBackColor = false;
            this.StuBtn.Click += new System.EventHandler(this.StuBtn_Click);
            // 
            // TeamBtn
            // 
            this.TeamBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.TeamBtn.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TeamBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TeamBtn.Location = new System.Drawing.Point(719, 345);
            this.TeamBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TeamBtn.Name = "TeamBtn";
            this.TeamBtn.Size = new System.Drawing.Size(182, 93);
            this.TeamBtn.TabIndex = 66;
            this.TeamBtn.Text = "队伍信息";
            this.TeamBtn.UseVisualStyleBackColor = false;
            this.TeamBtn.Click += new System.EventHandler(this.TeamBtn_Click);
            // 
            // TeaBtn
            // 
            this.TeaBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.TeaBtn.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TeaBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TeaBtn.Location = new System.Drawing.Point(436, 345);
            this.TeaBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TeaBtn.Name = "TeaBtn";
            this.TeaBtn.Size = new System.Drawing.Size(187, 93);
            this.TeaBtn.TabIndex = 65;
            this.TeaBtn.Text = "教师信息";
            this.TeaBtn.UseVisualStyleBackColor = false;
            this.TeaBtn.Click += new System.EventHandler(this.TeaBtn_Click);
            // 
            // printform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 503);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "printform";
            this.Text = "打印中心";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button StuBtn;
        private System.Windows.Forms.Button TeamBtn;
        private System.Windows.Forms.Button TeaBtn;
    }
}