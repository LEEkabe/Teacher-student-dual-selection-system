﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;

namespace system
{
    public partial class mainform : Form
    {
        int index = 0;
         DataTable dt;
        public mainform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //开始打印
            printDocument1.Print();
        }
        void printdoc_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.TranslateTransform(e.PageBounds.Width, e.PageBounds.Height);
            e.Graphics.RotateTransform(180);
            Font f = new Font("宋体", 50);
            e.Graphics.DrawString("hello", f, Brushes.Black, 50, 10);
        }

        private void button3_Click(object sender, EventArgs e)//yulan
        {
            index = 0;
            printPreviewDialog1.Document = printDocument1;

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            { printDocument1.Print(); }

          
        }

        private void mainform_Load(object sender, EventArgs e)
        {
            BLL.GetinStu stu = new BLL.GetinStu();
            //g = stu.selectg();
            //dt = SqlDbHelper.ExecuteDataTable("select * from [5_8_g]");
            dt = stu.selectg();
           
            printDocument1.PrintPage += new PrintPageEventHandler(printdoc_PrintPage1);
        }
        void printdoc_PrintPage1(object sender, PrintPageEventArgs e)
        {
            //Font f = new Font("宋体", 40);
            //int width, height;
            //width = printDocument1.DefaultPageSettings.PaperSize.Width;
            //height = printDocument1.DefaultPageSettings.PaperSize.Height;

            //e.Graphics.DrawString(string.Format("纸张宽：{0}，高：{1}", width, height),
            //    f, Brushes.Black, 100, 500);

            //Pen blackPen = new Pen(Color.Black, 3);
            //PointF point1 = new PointF(100.0F, 100.0F);
            //PointF point2 = new PointF(500.0F, 200.0F);
            //e.Graphics.DrawLine(blackPen, point1, point2);
            //Bitmap memoryImage;
            //memoryImage = new Bitmap(@"C:\Users\rock\Pictures\cat.jpg");
            //e.Graphics.DrawImage(memoryImage, 0, 0);  

            int y = 140;
            Font f = new Font("宋体", 20);

            e.Graphics.DrawString("队伍编号", f, Brushes.Black, 50, 80);
            e.Graphics.DrawString("志愿一", f, Brushes.Black, 200, 80);
            e.Graphics.DrawString("志愿二", f, Brushes.Black, 350, 80);
            e.Graphics.DrawString("志愿三", f, Brushes.Black, 500, 80);
            e.Graphics.DrawString("最终结果", f, Brushes.Black, 650, 80);

            for (; index < dt.Rows.Count; index++)
            {
                e.Graphics.DrawString(dt.Rows[index][0].ToString(), f, Brushes.Black, 100, y);
                e.Graphics.DrawString(dt.Rows[index][1].ToString(), f, Brushes.Black, 230, y);
                e.Graphics.DrawString(dt.Rows[index][2].ToString(), f, Brushes.Black, 380, y);
                e.Graphics.DrawString(dt.Rows[index][3].ToString(), f, Brushes.Black, 530, y);
                e.Graphics.DrawString(dt.Rows[index][4].ToString(), f, Brushes.Black, 650, y);
                y += 60;
                if (y >= e.PageBounds.Height - 100)
                {
                    index++;
                    e.HasMorePages = true;
                    break;
                }
            }
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }

    }
    }

