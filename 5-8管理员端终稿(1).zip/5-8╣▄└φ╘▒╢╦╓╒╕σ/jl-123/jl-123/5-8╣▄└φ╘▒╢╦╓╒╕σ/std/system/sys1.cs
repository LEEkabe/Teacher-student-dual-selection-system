﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class sys1 : UserControl
    {
        public sys1()
        {
            InitializeComponent();
        }  
        private void button2_Click(object sender, EventArgs e)
        {
            Model.messTable table = new Model.messTable();
            table.messTitle = textBox2.Text;//题目
            table.messContent = richTextBox1.Text;//内容
            table.sender ="administrators";//发送对象
            table.receiver = comboBox1.Text;
            table.grade = comboBox2.Text;
            table.profession = comboBox3.Text;
            table.time =DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            BLL.messTable b_table = new BLL.messTable();
            bool mes = b_table.messTrue(table);
             MessageBox.Show("发送成功！");
            richTextBox1.Clear();
            textBox2.Clear();
            
           
        }
           private void 重置_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            textBox2.Clear();
        }  

       

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            xxjl x = new xxjl();
            x.ShowDialog();
        }
        #region 文本框
        Boolean textboxHasText = false;//判断输入框是否有文本
       
         private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textboxHasText == false)
                textBox2.Text = "";

            textBox2.ForeColor = Color.Black;
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = " ";
                //textBox1.ForeColor = Color.LightGray;
                textboxHasText = false;
            }
            else
                textboxHasText = true;
        }
        #endregion
    
            private void sys1_Load(object sender, EventArgs e)
        {
            textBox2_Enter(null, EventArgs.Empty);
            textBox2_Leave(null, EventArgs.Empty);
        }

            private void label3_Click(object sender, EventArgs e)
            {

            }
       
       
        
    }
  
}