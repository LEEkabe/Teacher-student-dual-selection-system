﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{   
    public partial class xxjl : Form
    {
        DataTable dt; 
        DataTable g;
        DataTable s;
        int x;
        int y;
        string v;
        string Index;
        public static string str = "";

        public static string str1 = "";
        public xxjl()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void xxjl_Load(object sender, EventArgs e)
        {
            BLL.messTable messT = new BLL.messTable();
            g = messT.selectadm();
            //dataGridView1.Columns["title"].HeaderText = "标题";
            //dataGridView1.Columns["sender"].HeaderText = "发送人";
            //dataGridView1.Columns["grade"].HeaderText = "年级";
            //dataGridView1.Columns["profession"].HeaderText = "专业";
            //dataGridView1.Columns["time"].HeaderText = "时间";
            //dataGridView1.Columns["messcontent"].HeaderText = "内容";
            //dataGridView1.Columns["receiver"].HeaderText = "收件人";
            this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
            this.Top = Screen.PrimaryScreen.Bounds.Height / 2 - this.Height / 2;//桌面的高度的一半减去自身高度的一半this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
           
            dataGridView1.DataSource = g;
            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public DataGridViewRow dataGridViewRow;
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            dataGridViewRow = dataGridView1.CurrentRow;
            tzxq xx = new tzxq();
            xx.grade = dataGridView1.CurrentRow.Cells["grade"].Value.ToString();
            xx.pro = dataGridView1.CurrentRow.Cells["profession"].Value.ToString();
            xx.sende = dataGridView1.CurrentRow.Cells["sender"].Value.ToString();
            xx.time = dataGridView1.CurrentRow.Cells["time"].Value.ToString();
            xx.content = dataGridView1.CurrentRow.Cells["messcontent"].Value.ToString();
            xx.title = dataGridView1.CurrentRow.Cells["title"].Value.ToString();
            xx.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Model.messTable messTable = new Model.messTable();
            int index = dataGridView1.CurrentRow.Index;    //取得选中行的索引  
            this.dataGridView1.Rows.RemoveAt(index);
            string i = dataGridView1.Rows[index].Cells["time"].Value.ToString();
            messTable.times = i;
            BLL.messTable mess = new BLL.messTable();
            string msg;
            bool res = mess.Del(messTable, out msg);
            //BLL.messTable mess = new BLL.messTable();
            //if (dataGridView1.DataSource == s)
            //{
            //    mess.update(s);
            //    if (mess.update(s))
            //        MessageBox.Show("修改成功");
            //}
        }

        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            x = dataGridView1.CurrentCell.RowIndex;//
            y = dataGridView1.CurrentCell.ColumnIndex;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            v = Convert.ToString(dataGridView1[y, x].Value);

            //v = Convert.ToString(dataGridView1.Rows[x].Cells[y].Value);
            s.Rows[x][y] = v;
        }

      
    }
}
