﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;
using System.Data.OleDb;
using System.IO;


namespace system
{
    public partial class sys2 : UserControl
    {
        DataTable s;
        //DataTable j;
        int x;
        int y;
        string v;
        string id; bool MAJ;
        bool GRA; bool res1; int Q = 0;
        DataTable dt_student;
        BLL.GetinStu Stu = new BLL.GetinStu();
        public sys2()
        {
            InitializeComponent();
        }

        private void sys2_Load(object sender, EventArgs e)
        {
            s = Stu.getList();//获得值
           // s =Stu.select();
            dataGridView1.DataSource = s;
            dataGridView1.Columns[0].ReadOnly = true;
            dataGridView1.Columns["studentname"].HeaderText = "名字";
            dataGridView1.Columns["studentid"].HeaderText = "学号";
            dataGridView1.Columns["studentclass"].HeaderText = "班级";
            dataGridView1.Columns["studentprofession"].HeaderText = "专业";
            dataGridView1.Columns["studentacademy"].HeaderText = "学院";
            dataGridView1.Columns["studentgrade"].HeaderText = "年级";
            dataGridView1.Columns["studentnumber"].HeaderText = "电话号码";
            dataGridView1.Columns["studentsex"].HeaderText = "性别";
            dataGridView1.Columns["studentage"].HeaderText = "年龄";
            dataGridView1.Columns["studentpolitical"].HeaderText = "政治面貌";
            try
            {
                dataGridView1.DataSource = s;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString());
            }

            
            //j = s;
        }
        public static string gete(string path)
        {
            string tablename = null;
            if (File.Exists(path))
            {
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
                    + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'"))
                {
                    conn.Open();
                    tablename = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0][2].ToString().Trim();
                }
            }
            return tablename;
        }
        public static DataSet etds(string filename, string tsql)
        {
            DataSet ds;
            string strcon = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
                + filename + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
            OleDbConnection myConn = new OleDbConnection(strcon);
            string strcom = tsql;
            myConn.Open();
            OleDbDataAdapter mycommand = new OleDbDataAdapter(strcom, myConn);
            ds = new DataSet();
            mycommand.Fill(ds);
            //使用OleDbDataAdapter对象mycommand将查询结果填充到DataTable对象ds中
            myConn.Close();
            return ds;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Addstudent a = new Addstudent();
            a.ShowDialog();
        }

        private void dataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            //DataTable j;
            //dataGridView1.DataSource = j;

        }


        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            x = dataGridView1.CurrentCell.RowIndex;//
            y = dataGridView1.CurrentCell.ColumnIndex;

            //id = dataGridView1[x, 0].Value.ToString();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellValueChanged_1(object sender, DataGridViewCellEventArgs e)
        {
            v = Convert.ToString(dataGridView1[y,x].Value);

            //v = Convert.ToString(dataGridView1.Rows[x].Cells[y].Value);
            s.Rows[x][y] = v;
            //DataRow[] dr = s.Select("studentid'" + id + "'");
            //dr[y][x] = v;
            //if (dataGridView1.DataSource == s)
            //{
            //    s.Rows[y][x] = v;
            //}
            //else if (dataGridView1.DataSource == dt_student)
            //{
            //    dt_student.Rows[y][x] = v;
            //}
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource == s)
            {
                Stu.ups(s);
                if (Stu.ups(s))
                    MessageBox.Show("刷新成功");
            }
            else if (dataGridView1.DataSource == dt_student)
            {
                Stu.upst(dt_student);
                if (Stu.ups(dt_student))
                    MessageBox.Show("修改成功");
            }
          
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "全部" && comboBox2.Text != "全部")
            {
                Model.stu model = new Model.stu();
                model.studentgrade = comboBox1.Text;
                model.studentprofession = comboBox2.Text;
                BLL.GetinStu bll = new BLL.GetinStu();
                dt_student = bll.Getstudent(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text != "全部" && comboBox2.Text == "全部")
            {
                Model.stu model = new Model.stu();
                model.studentgrade = comboBox1.Text;
                //model.studentprofession = comboBox2.Text;
                BLL.GetinStu bll = new BLL.GetinStu();
                dt_student = bll.Getstudenta(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text != "全部")
            {
                Model.stu model = new Model.stu();
                //model.studentgrade = comboBox1.Text;
                model.studentprofession = comboBox2.Text;
                BLL.GetinStu bll = new BLL.GetinStu();
                dt_student = bll.Getstudentb(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text == "全部")
            {
                Model.stu model = new Model.stu();
                //model.studentgrade = comboBox1.Text;
                //model.studentprofession = comboBox2.Text;
                BLL.GetinStu bll = new BLL.GetinStu();
                dt_student = bll.Getstudentc(model);
                this.dataGridView1.DataSource = dt_student;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            DataGridViewRow row = dataGridView1.Rows[i];
            dataGridView1.Rows.Remove(row);
       
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text != "" && comboBox1.Text != "")
            {
                try
                {
                    OpenFileDialog ofd = new OpenFileDialog();
                    ofd.Filter = "Excel文件|*.xlsx|所有文件|*.*";
                    ofd.Title = "打开文件夹";
                    string b = "";
                    ofd.InitialDirectory = "e:\\";
                    ofd.FilterIndex = 1;
                    if (ofd.ShowDialog() == DialogResult.OK)  //如果点击的是打开文件
                    {
                        this.textBox3.Text = ofd.FileName;  //获取全路径文件名
                        b = this.textBox3.Text;
                    }
                    string tablename = gete(b);
                    string TSql = "SELECT*FROM[" + tablename + "]";
                    DataTable table = etds(b, TSql).Tables[0];
                    dataGridView1.DataSource = table;
                    foreach (DataGridViewRow dgr in dataGridView1.Rows)
                    {
                        CurrencyManager myCM = (CurrencyManager)BindingContext[dataGridView1.DataSource];
                        myCM.SuspendBinding();//挂起数据绑定


                        if (dgr.Cells["studentid"].Value == null)
                        {
                            break;
                        }
                        if (comboBox1.Text == dgr.Cells["studentgrade"].Value.ToString() && comboBox2.Text == dgr.Cells["studentprofession"].Value.ToString())
                        {
                            dgr.Visible = true;

                        }
                        else
                        {
                            dgr.Visible = false;
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("请选择导入的年级和专业！");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            MAJ = true;
            GRA = true;
            if (MAJ == true && GRA == true)//学生，选专业，选年级
            {
                //getACA();
                Model.stu table = new Model.stu();
                BLL.import b = new BLL.import();
                foreach (DataGridViewRow dgr in dataGridView1.Rows)
                {
                    if (dgr.Cells["studentid"].Value == null)
                    {
                        break;
                    }
                    if (comboBox2.Text == dgr.Cells["studentprofession"].Value.ToString() && comboBox1.Text == dgr.Cells["studentgrade"].Value.ToString())
                    {
                        table.studentname = dgr.Cells["studentname"].Value.ToString();
                        table.studentid = dgr.Cells["studentid"].Value.ToString();
                        table.studentclass = dgr.Cells["studentclass"].Value.ToString();
                        table.studentprofession = dgr.Cells["studentprofession"].Value.ToString();
                        table.studentacademy = dgr.Cells["studentacademy"].Value.ToString();
                        table.studentnumber = dgr.Cells["studentnumber"].Value.ToString();
                        table.studentsex = dgr.Cells["studentsex"].Value.ToString();
                        table.studentage = dgr.Cells["studentage"].Value.ToString();
                        table.studentpolitical = dgr.Cells["studentpolitical"].Value.ToString();
                        table.studentgrade = comboBox1.Text;
                        table.studentprofession = comboBox2.Text;

                        bool res = b.INstu(table);
                        res1 = res;
                        Q++;
                    }

                }
            }
            if (res1 == true)
            {
                MessageBox.Show("导入成功！");

            }
            else
                MessageBox.Show("导入失败！表中无对应数据！");

        }
    }
}
