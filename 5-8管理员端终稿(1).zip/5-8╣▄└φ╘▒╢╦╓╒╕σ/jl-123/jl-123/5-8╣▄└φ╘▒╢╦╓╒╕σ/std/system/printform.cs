﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class printform : Form
    {
        public printform()
        {
            InitializeComponent();
        }

        private void StuBtn_Click(object sender, EventArgs e)
        {
            printstu a = new printstu();
            a.Show();
            this.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TeaBtn_Click(object sender, EventArgs e)
        {
            printtea a = new printtea();
            a.Show();
            this.Close();
        }

        private void TeamBtn_Click(object sender, EventArgs e)
        {
            printgroup a = new printgroup();
            a.Show();
            this.Close();
        }
    }
}
