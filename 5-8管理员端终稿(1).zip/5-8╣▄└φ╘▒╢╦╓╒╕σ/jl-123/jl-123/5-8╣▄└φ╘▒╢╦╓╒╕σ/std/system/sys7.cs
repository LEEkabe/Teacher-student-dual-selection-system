﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class sys7 : UserControl
    {
        DataTable g;
        //BLL.messTable Stu = new BLL.GetinStu();
        public sys7()
        {
            InitializeComponent();
        }

        private void checkedListBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void sys7_Load(object sender, EventArgs e)
        {
            BLL.messTable messT = new BLL.messTable();
            g = messT.select();
            dataGridView1.DataSource = g;
        }

        public DataGridViewRow dataGridViewRow;

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dataGridViewRow =dataGridView1.CurrentRow;
            feebackdetail xx = new feebackdetail();
            xx.grade = dataGridView1.CurrentRow.Cells["grade"].Value.ToString();
            xx.pro = dataGridView1.CurrentRow.Cells["profession"].Value.ToString();
            xx.sende = dataGridView1.CurrentRow.Cells["sender"].Value.ToString();
            xx.time = dataGridView1.CurrentRow.Cells["time"].Value.ToString();
            xx.content = dataGridView1.CurrentRow.Cells["messcontent"].Value.ToString();
            
            xx.ShowDialog();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            DataGridViewRow row = dataGridView1.Rows[i];
            dataGridView1.Rows.Remove(row);
        }
    }
}
