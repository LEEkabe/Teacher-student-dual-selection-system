﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;
using System.Data.OleDb;
using System.IO;


namespace system
{
    public partial class sys3 : UserControl
    {
        int x;
        int y;
        string v;
        DataTable t; int Q = 0;
        bool res1;
        bool MAJ;
        bool GRA;
        DataTable dt_teacher;
        BLL.GetinTea Tea = new BLL.GetinTea();
        public sys3()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        private void sys3_Load(object sender, EventArgs e)
        {
            
            t = Tea.select();
            dataGridView1.DataSource = t;
            dataGridView1.Columns[0].ReadOnly = true;
            this.dataGridView1.Columns[1].Visible = false;
            this.dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns["id"].HeaderText = "工号";
            dataGridView1.Columns["name"].HeaderText = "姓名";
            dataGridView1.Columns["major"].HeaderText = "主修";
            dataGridView1.Columns["profession"].HeaderText = "专业";
            dataGridView1.Columns["academy"].HeaderText = "学院";
            dataGridView1.Columns["grade"].HeaderText = "年级";
            dataGridView1.Columns["phone"].HeaderText = "电话号码";
            dataGridView1.Columns["sex"].HeaderText = "性别";
            dataGridView1.Columns["year"].HeaderText = "年龄";
            dataGridView1.Columns["jobtitle"].HeaderText = "职称";
        }

        private void dataGridView1_CellBeginEdit_1(object sender, DataGridViewCellCancelEventArgs e)
        {
            x = dataGridView1.CurrentCell.RowIndex;//
            y = dataGridView1.CurrentCell.ColumnIndex;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            v = Convert.ToString(dataGridView1[x, y].Value);
            t.Rows[y][x] = v;
        }
        public static string gete(string path)
        {
            string tablename = null;
            if (File.Exists(path))
            {
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
                    + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'"))
                {
                    conn.Open();
                    tablename = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0][2].ToString().Trim();
                }
            }
            return tablename;
        }
        public static DataSet etds(string filename, string tsql)
        {
            DataSet ds;
            string strcon = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
                + filename + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
            OleDbConnection myConn = new OleDbConnection(strcon);
            string strcom = tsql;
            myConn.Open();
            OleDbDataAdapter mycommand = new OleDbDataAdapter(strcom, myConn);
            ds = new DataSet();
            mycommand.Fill(ds);
            //使用OleDbDataAdapter对象mycommand将查询结果填充到DataTable对象ds中
            myConn.Close();
            return ds;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Tea.updatetea(t);
            if (Tea.updatetea(t))
                MessageBox.Show("刷新成功");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "全部" && comboBox2.Text != "全部")
            {
                Model.tea model = new Model.tea();
                model.grade = comboBox2.Text;
                model.profession = comboBox1.Text;
                BLL.GetinTea bll = new BLL.GetinTea();
                dt_teacher = bll.Getteacher(model);
                this.dataGridView1.DataSource = dt_teacher;
            }
            else if (comboBox1.Text != "全部" && comboBox2.Text == "全部")
            {
                Model.tea model = new Model.tea();
                //model.grade = comboBox2.Text;
                model.profession = comboBox1.Text;
                BLL.GetinTea bll = new BLL.GetinTea();
                dt_teacher = bll.Getteachera(model);
                this.dataGridView1.DataSource = dt_teacher;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text != "全部")
            {
                Model.tea model = new Model.tea();
                model.grade = comboBox2.Text;
                //model.profession = comboBox1.Text;
                BLL.GetinTea bll = new BLL.GetinTea();
                dt_teacher = bll.Getteacherb(model);
                this.dataGridView1.DataSource = dt_teacher;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text == "全部")
            {
                Model.tea model = new Model.tea();
                //model.grade = comboBox2.Text;
                //model.profession = comboBox1.Text;
                BLL.GetinTea bll = new BLL.GetinTea();
                dt_teacher = bll.Getteacherc(model);
                this.dataGridView1.DataSource = dt_teacher;
            }
        }
        
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
       /*    OpenFileDialog file = new OpenFileDialog();

            file.Filter = "Excel(*.xlsx)|*.xlsx|Excel(*.xls)|*.xls";

            file.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            file.Multiselect = false;

            if (file.ShowDialog() == DialogResult.Cancel)

                return;*/
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Addteacher a = new Addteacher();
            a.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (comboBox2.Text != "" && comboBox1.Text != "")
            {
                try
                {
                    OpenFileDialog ofd = new OpenFileDialog();
                    ofd.Filter = "Excel文件|*.xlsx|所有文件|*.*";
                    ofd.Title = "打开文件夹";
                    string b = "";
                    ofd.InitialDirectory = "e:\\";
                    ofd.FilterIndex = 1;
                    if (ofd.ShowDialog() == DialogResult.OK)  //如果点击的是打开文件
                    {
                        b = ofd.FileName;  //获取全路径文件名

                    }
                    string tablename = gete(b);
                    string TSql = "SELECT*FROM[" + tablename + "]";
                    DataTable table = etds(b, TSql).Tables[0];
                    dataGridView1.DataSource = table;
                    foreach (DataGridViewRow dgr in dataGridView1.Rows)
                    {
                        CurrencyManager myCM = (CurrencyManager)BindingContext[dataGridView1.DataSource];
                        myCM.SuspendBinding();//挂起数据绑定


                        if (dgr.Cells["id"].Value == null)
                        {
                            break;
                        }
                        if (comboBox2.Text == dgr.Cells["grade"].Value.ToString() && comboBox1.Text == dgr.Cells["profession"].Value.ToString())
                        {
                            dgr.Visible = true;

                        }
                        else
                        {
                            dgr.Visible = false;
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("请选择导入的年级和专业！");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MAJ = true;
            GRA = true;
            if (MAJ == true && GRA == true)
            {

                Model.tea table = new Model.tea();
                BLL.import b = new BLL.import();
                foreach (DataGridViewRow dgr in dataGridView1.Rows)
                {
                    if (dgr.Cells["id"].Value == null)
                    {
                        break;
                    }
                    if (comboBox1.Text == dgr.Cells["profession"].Value.ToString() && comboBox2.Text == dgr.Cells["grade"].Value.ToString())
                    {

                        table.userName = dgr.Cells["userName"].Value.ToString();
                        table.userPassword = dgr.Cells["userPassword"].Value.ToString();
                        table.id = dgr.Cells["id"].Value.ToString();
                        table.name = dgr.Cells["name"].Value.ToString();
                        table.sex = dgr.Cells["sex"].Value.ToString();
                        table.year = dgr.Cells["year"].Value.ToString();
                        table.jobtitle = dgr.Cells["jobtitle"].Value.ToString();
                        table.phone = dgr.Cells["phone"].Value.ToString();
                        table.major = dgr.Cells["major"].Value.ToString();
                        table.academy = dgr.Cells["academy"].Value.ToString();

                        table.grade = comboBox2.Text.Trim();
                        table.profession = comboBox1.Text.Trim();

                        bool res = b.INtech(table);
                        res1 = res;
                        Q++;
                    }

                }
            }
            if (res1 == true)
            {
                MessageBox.Show("导入成功！");

            }
            else
                MessageBox.Show("导入失败！表中无对应数据！");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            DataGridViewRow row = dataGridView1.Rows[i];
            dataGridView1.Rows.Remove(row);
        }
    }
}
