﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class tzxq : Form
    {
        public string grade;
        public string pro;
        public string sende;
        public string time;
        public string content;
        public string title;

        public tzxq()
        {
            InitializeComponent();
        }

        private void tzxq_Load(object sender, EventArgs e)
        {
            label2.Text = grade;
            label3.Text = pro;
            label4.Text = sende;
            label5.Text = time;
            label6.Text = title;

            richTextBox1.Text = content;
            this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
            this.Top = Screen.PrimaryScreen.Bounds.Height / 2 - this.Height / 2;//桌面的高度的一半减去自身高度的一半this.Left = Screen.PrimaryScreen.Bounds.Width / 2 - this.Width / 2;//桌面的宽度的一半减去自身宽的的一半
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
