﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class sys6 : UserControl
    {
        public sys6()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void sys6_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && comboBox2.Text != "")
            {
                if (comboBox3.Text != "")
                {
                    if (comboBox3.Text == "学生")
                    {
                        if (domainUpDown3.Text != "")
                        {
                            Model.rule model = new Model.rule();
                            model.scount = domainUpDown3.Text.Trim();//学生修改次数
                            model.sstart = Convert.ToString(dateTimePicker2.Text.Trim());
                            model.sddl = Convert.ToString(dateTimePicker1.Text.Trim());
                            model.grade = comboBox2.Text.Trim();
                            model.profession = comboBox1.Text.Trim();
                            BLL.rule r = new BLL.rule();
                            if (r.guize2(model))
                            {
                                MessageBox.Show("发送成功");
                                domainUpDown2.Text = ""; domainUpDown4.Text = ""; domainUpDown1.Text = ""; domainUpDown3.Text = ""; 
                                dateTimePicker2.Text = "";
                                dateTimePicker1.Text = "";
                                comboBox1.Text = "";
                                comboBox2.Text = "";
                                comboBox3.Text = "";
                            }
                            else
                            {
                                MessageBox.Show("发送失败");
                            }
                        }
                        else
                        {
                            MessageBox.Show("请选择修改次数");
                        }
                    }
                    if (comboBox3.Text == "老师")
                    {
                        if (domainUpDown2.Text != "")
                        {
                            Model.rule model = new Model.rule();
                            model.count = domainUpDown1.Text.Trim();//laoshixiugaicishu
                            model.start = Convert.ToString(dateTimePicker3.Text.Trim());
                            model.ddl = Convert.ToString(dateTimePicker4.Text.Trim());
                            model.grade = comboBox2.Text.Trim();
                            model.profession = comboBox1.Text.Trim();
                            model.leveel = domainUpDown2.Text.Trim();
                            model.choice = domainUpDown4.Text.Trim();
                            BLL.rule r = new BLL.rule();
                            if (r.guize1(model))
                            {
                                MessageBox.Show("发送成功");
                                domainUpDown2.Text = ""; domainUpDown4.Text = ""; domainUpDown1.Text = ""; domainUpDown3.Text = ""; 
                                dateTimePicker3.Text = "";
                                dateTimePicker4.Text = "";
                                comboBox1.Text = "";
                                comboBox2.Text = "";
                                comboBox3.Text = "";
                            }
                            else
                            {
                                MessageBox.Show("发送失败");
                            }
                        }
                        else
                        {
                            MessageBox.Show("请选择修改次数");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("请正确选择发送对象");
                }

            }
            else
            {
                MessageBox.Show("请选择年级专业");
            }
        }

        private void domainUpDown4_SelectedItemChanged(object sender, EventArgs e)
        {

        }
    }
}
