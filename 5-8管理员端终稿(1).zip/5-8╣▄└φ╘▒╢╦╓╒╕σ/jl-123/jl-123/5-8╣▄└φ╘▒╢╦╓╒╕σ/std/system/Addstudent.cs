﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class Addstudent : Form
    {
        public Addstudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                Model.stu student = new Model.stu();
                student.studentname = textBox1.Text;
                student.studentid = textBox2.Text;
                student.studentgrade = textBox3.Text;
                student.studentprofession = textBox4.Text;
                student.studentnumber = textBox5.Text;
                BLL.GetinStu stu = new BLL.GetinStu();
                bool res = stu.addstudent(student);
                if (res)
                {
                    MessageBox.Show("添加成功！");
                }
            }
            else 
            {
                MessageBox.Show("名字和学号不能为空！");
            }
        }
    }
}
