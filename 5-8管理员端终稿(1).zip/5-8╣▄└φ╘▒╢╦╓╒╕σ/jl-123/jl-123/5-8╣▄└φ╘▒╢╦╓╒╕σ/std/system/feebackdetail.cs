﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class feebackdetail : Form
    {
        public string grade;
        public string pro;
        public string sende;
        public string time;
        public string content;




        public feebackdetail()
        {
            InitializeComponent();
        }

        private void feebackdetail_Load(object sender, EventArgs e)
        {
            label2.Text = grade;
            label3.Text = pro;
            label4.Text = sende;
            label5.Text = time;

            richTextBox1.Text = content;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
