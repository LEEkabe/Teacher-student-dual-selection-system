﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;

namespace system
{
    public partial class sys4 : UserControl
    {
        int index = 0;
        DataTable dt;
        DataTable f;
        public sys4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            xszy xx = new xszy();
            xx.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lszy ls = new lszy();
            ls.ShowDialog();
        }

        private void sys4_Load(object sender, EventArgs e)
        {
            BLL.fenpei fen = new BLL.fenpei ();
            f = fen.select();
            //dataGridView1.DataSource = f;
            //dataGridView1.Columns[0].ReadOnly = true;
            // dt = SqlDbHelper.ExecuteDataTable("select * from [5_8_g]");
           
            //printDocument1.PrintPage += new PrintPageEventHandler(printdoc_PrintPage1);

           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            printform f = new printform();
            f.ShowDialog();
            //开始打印
           // printDocument1.Print();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            match m = new match();
            m.ShowDialog();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
