﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class fpjg : Form
    {
        DataTable f;
        BLL.fenpei fen = new BLL.fenpei();
        public fpjg()
        {
            InitializeComponent();
        }

        private void fpjg_Load(object sender, EventArgs e)
        {
            
            f = fen.temtable();
            dataGridView1.DataSource = f;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(fen.uptemtable(f))
            {
                MessageBox.Show("保存成功！");
            }
        }
    }
}
