﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class sys8 : UserControl
    {
        Model.User User = new Model.User();

        public sys8()
        {
            InitializeComponent();
        }

        private void sys8_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text != Model.publicuser.Pwd)
            {
                MessageBox.Show("原密码错误！");
                return;
            }
            if (textBox1.Text != textBox4.Text)
            {
                MessageBox.Show("两次密码不一样！");
                return;
            }
            if (textBox1.Text == "")
            {
                MessageBox.Show("密码不能为空！");
            }
            if (textBox4.Text == "")
            {
                MessageBox.Show("密码不能为空！");
            }

            User.Id = Model.publicuser.Id;
            User.Pwd = textBox1.Text;
            string msg;
            BLL.User user = new BLL.User();
            bool res = user.update(User, out msg);
            MessageBox.Show("提交成功！");
        }
    }
}
