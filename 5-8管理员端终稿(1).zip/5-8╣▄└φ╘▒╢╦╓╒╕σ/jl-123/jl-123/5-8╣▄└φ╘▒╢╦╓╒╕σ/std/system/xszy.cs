﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;
using DAL;
namespace system
{
    public partial class xszy : Form
    {
        int index = 0; DataTable dt;
        DataTable g;
        DataTable dt_student;
        BLL.GetinStu Stu = new BLL.GetinStu();
        public xszy()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void xszy_Load(object sender, EventArgs e)
        {
            BLL.GetinStu stu = new BLL.GetinStu();
            g = stu.selectg();
            dataGridView1.DataSource = g; 
            dataGridView1.Columns["g_id"].HeaderText = "组号";
            dataGridView1.Columns["c1"].HeaderText = "志愿一";
            dataGridView1.Columns["c2"].HeaderText = "志愿二";
            dataGridView1.Columns["c3"].HeaderText = "志愿三";
            dataGridView1.Columns["grade"].HeaderText = "年级";
            dataGridView1.Columns["profession"].HeaderText = "专业";
        }
       
      
        private void button2_Click(object sender, EventArgs e)
        {
            Model.stu model = new Model.stu();
            model.studentgrade = comboBox1.Text;
            model.studentprofession = comboBox2.Text;
            BLL.GetinStu bll = new BLL.GetinStu();
            dt_student = bll.Getstudent(model);
            this.dataGridView1.DataSource = dt_student;
            if (comboBox1.Text != "全部" && comboBox2.Text != "全部")
            {
                Model.stu stu = new Model.stu();
                model.studentgrade = comboBox1.Text;
                model.studentprofession = comboBox2.Text;
                BLL.GetinStu bstu = new BLL.GetinStu();
                dt_student = bstu.Getstudent(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text != "全部" && comboBox2.Text == "全部")
            {
                Model.stu stu= new Model.stu();
                model.studentgrade = comboBox1.Text;
                //model.studentprofession = comboBox2.Text;
                BLL.GetinStu bstu = new BLL.GetinStu();
                dt_student = bll.Getstudenta(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text != "全部")
            {
                Model.stu stu = new Model.stu();
                //model.studentgrade = comboBox1.Text;
                model.studentprofession = comboBox2.Text;
                BLL.GetinStu bstu = new BLL.GetinStu();
                dt_student = bll.Getstudentb(model);
                this.dataGridView1.DataSource = dt_student;
            }
            else if (comboBox1.Text == "全部" && comboBox2.Text == "全部")
            {
                Model.stu stu = new Model.stu();
                //model.studentgrade = comboBox1.Text;
                //model.studentprofession = comboBox2.Text;
                BLL.GetinStu bstu = new BLL.GetinStu();
                dt_student = bll.Getstudentc(model);
                this.dataGridView1.DataSource = dt_student;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mainform f = new mainform();
            f.ShowDialog();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
