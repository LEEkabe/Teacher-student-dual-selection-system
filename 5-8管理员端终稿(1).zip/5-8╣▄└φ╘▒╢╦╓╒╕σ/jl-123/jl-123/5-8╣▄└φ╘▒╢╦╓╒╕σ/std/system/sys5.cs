﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace system
{   
    public partial class sys5 : UserControl
    {
        DataTable dt_student;
        SqlDataAdapter sda;
        DataTable dt;
        DataTable r;
        public sys5()
        {
            InitializeComponent();
        }
        private void ViewUser_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            sda = new SqlDataAdapter("select * from [5_8_team]", "Data Source=.;Initial Catalog=xg2019;uid=stu;pwd=123");
            sda.Fill(dt);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            dataGridView1.DataSource = dt;

            //BLL.User b_user = new BLL.User();
            //dt = b_user.list_user();
            //dataGridView1.DataSource = dt;
            //同步修改数据库  private void button1_Click(object sender, EventArgs e)
            //{
            //    //sda.Update(dt);
            //    BLL.User b_user = new BLL.User();
            //    if (b_user.update_users(dt))
            //        MessageBox.Show("ok!");
            //}
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void sys5_Load(object sender, EventArgs e)
        {
            //BLL.Result re = new BLL.Result();
            //r = re.st();
            //dataGridView1.DataSource = r;
            //dataGridView1.Columns[0].ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Model.stu model = new Model.stu();
            //model.studentgrade = comboBox1.Text;
            //model.studentprofession = comboBox2.Text;
            //BLL.GetinStu bll = new BLL.GetinStu();
            //dt_student = bll.Getstudent(model);
            //this.dataGridView1.DataSource = dt_student;
            Model.Result result = new Model.Result();
            result.grade = comboBox1.Text;
            result.profession = comboBox2.Text;

            if (comboBox3.Text== "老师") 
            {
                BLL.Result re = new BLL.Result();
                r = re.stea(result);
                dataGridView1.DataSource = r;
            }
            if (comboBox3.Text == "学生")
            {
                BLL.Result re = new BLL.Result();
                r = re.sstu(result);
                dataGridView1.DataSource = r;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
