﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class glogin : Form
    {
        public glogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if ((textBox1.Text != null) && (textBox2.Text != null))
            //{
            //    if (textBox1.Text == "admin3" && textBox2.Text == "123456")
            //    {
            //        glogin1 m = new glogin1();
            //        m.ShowDialog();
            //        this.Hide();

            //    }
            //    else
            //    {
            //        MessageBox.Show("用户名或密码错误");
            //        textBox1.Text = "";
            //        textBox2.Text = "";
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("请输入用户名和密码", "提示");
            //}

            string uid = textBox1.Text;//得到用户名和密码
            string pwd = textBox2.Text;

            Model.User m_user = new Model.User();
            m_user.Id = uid;
            m_user.Pwd = pwd;

            BLL.User b_user = new BLL.User();
            int res = b_user.Login(m_user);
            if (res == 0)
            {
                //this.DialogResult = DialogResult.OK;
                glogin1 m = new glogin1();
                m.Show();
                this.Hide();
            }
            else if (res == 1)
                MessageBox.Show("用户名和密码不对！");
        }

      
        //[DllImport("user32.dll")]

        //public static extern bool ReleaseCapture();
        //[DllImport("user32.dll")]

        //public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);

        //public void MouseDo_1(IntPtr MDl)
        //{
        //   int WM_SYSCOMMAND = 0x0112;
        //    int SC_MOVE = 0xF010;
        //    int HTCAPTION = 0x002;

        //    ReleaseCapture();
        //    SendMessage(MDl, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        //}
        private void glogin_MouseDown(object sender, MouseEventArgs e)
        {
          //  MouseDo_1(this.Handle);
            if (e.Button == MouseButtons.Left)
              {
                  mouseOff = new Point(-e.X, -e.Y); //得到变量的值
                  leftFlag = true;                  //点击左键按下时标注为true;
              }
        }
        private Point mouseOff;//鼠标移动位置变量
        private bool leftFlag;

        private void glogin_MouseMove(object sender, MouseEventArgs e)
        {
            if (leftFlag)
             {
                 Point mouseSet = Control.MousePosition;
                 mouseSet.Offset(mouseOff.X, mouseOff.Y);  //设置移动后的位置
                 Location = mouseSet;
             }
        }

        private void glogin_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftFlag)
              {
                  leftFlag = false;//释放鼠标后标注为false;
              }
        }//标签是否为左键
    }
}
