﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class Addteacher : Form
    {
        Model.tea tea = new Model.tea();
        public Addteacher()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                tea.id = textBox2.Text;
                tea.name = textBox1.Text;
                tea.grade = textBox3.Text;
                tea.profession = textBox4.Text;
                tea.userName = textBox5.Text;
                tea.userPassword = textBox6.Text;
                BLL.GetinTea gettea = new BLL.GetinTea();
                bool res = gettea.addtea(tea);
                bool red = gettea.addteacher(tea);
                if (res)
                {
                    MessageBox.Show("添加成功！");
                }
            }
            else
            {
                MessageBox.Show("名字和职工号不能为空！");
            }
        }
    }
}
