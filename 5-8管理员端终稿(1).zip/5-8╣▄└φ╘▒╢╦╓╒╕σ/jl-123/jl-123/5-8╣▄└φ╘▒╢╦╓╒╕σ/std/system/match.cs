﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class match : Form
    {
        DataTable g;
        DataTable t;
        DataTable score;
        DataTable sco;
        int T_groups = 5;
        int G_teachers = 3;
        DataTable t_res;
        DataTable g_res;
        int o = 0;
        public match()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void match_Load(object sender, EventArgs e)
        {
            //BLL.GetinStu stu = new BLL.GetinStu();
            //g = stu.selectg();
            //dataGridView1.DataSource = g;

            //BLL.GetinTea tea = new BLL.GetinTea();
            //t = tea.selectt();
            //dataGridView2.DataSource = t;

            //make_table();
            //dataGridView3.DataSource = score;

            //count_score();
            //t_res = t.Copy();
            //g_res = g.Copy();
            //dataGridView4.DataSource = g_res;
            //dataGridView5.DataSource = t_res;
        }

        void count_score()
        {
            for (int i = 0; i < g.Rows.Count; i++)
            {
                int gid = Convert.ToInt32(g.Rows[i]["g_id"]);

                for (int j = 0; j < t.Rows.Count; j++)
                {
                    int tid = Convert.ToInt32(t.Rows[j]["id"]);

                    int[] S_c = { 0, 0, 0 };
                    int[] T_c = { 0, 0, 0, 0, 0 };

                    double marks_s = 0.0;
                    double marks_t = 0.0;

                    for (int n = 0; n < G_teachers; n++)
                    {
                        int tmp_c = Convert.ToInt32(g.Rows[i][n + 1]);
                        if (tmp_c == tid) S_c[n] = 1;
                        marks_s += Math.Pow(S_c[n] * 2, G_teachers - n);
                    }

                    for (int n = 0; n < T_groups; n++)
                    {
                        int tmp_c = Convert.ToInt32(t.Rows[j][n + 1]);
                        if (tmp_c == gid) T_c[n] = 1;
                        marks_t += Math.Pow(T_c[n] * 2, T_groups - n);
                    }

                    DataRow dr = score.NewRow();
                    dr["组ID"] = gid;
                    dr["老师ID"] = tid;
                    dr["S_c1"] = S_c[0];
                    dr["S_c2"] = S_c[1];
                    dr["S_c3"] = S_c[2];
                    dr["T_c1"] = T_c[0];
                    dr["T_c2"] = T_c[1];
                    dr["T_c3"] = T_c[2];
                    dr["T_c4"] = T_c[3];
                    dr["T_c5"] = T_c[4];
                    dr["得分"] = marks_s + marks_t * 1.1;
                    dr["已分配"] = 0;

                    //DataRow dw = sco.NewRow();
                    //dr["tid"] = tid;


                    score.Rows.Add(dr);
                }
            }

            dataGridView3.DataSource = score;
        }

        void make_table()
        {
            score = new DataTable();
            score.Columns.Add("组ID", Type.GetType("System.Int32"));
            score.Columns.Add("老师ID", Type.GetType("System.Int32"));
            score.Columns.Add("S_c1", Type.GetType("System.Int32"));
            score.Columns.Add("S_c2", Type.GetType("System.Int32"));
            score.Columns.Add("S_c3", Type.GetType("System.Int32"));
            score.Columns.Add("T_c1", Type.GetType("System.Int32"));
            score.Columns.Add("T_c2", Type.GetType("System.Int32"));
            score.Columns.Add("T_c3", Type.GetType("System.Int32"));
            score.Columns.Add("T_c4", Type.GetType("System.Int32"));
            score.Columns.Add("T_c5", Type.GetType("System.Int32"));
            score.Columns.Add("得分", Type.GetType("System.Single"));
            score.Columns.Add("已分配", Type.GetType("System.Int32"));

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataView dataView = score.DefaultView;
            dataView.RowFilter = "得分>0";
            dataView.Sort = "得分 DESC";
            score = dataView.ToTable();
            dataGridView3.DataSource = score;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (o != 0)
            {
                o = 2;
                //过滤
                DataView dataView = score.DefaultView;
                dataView.RowFilter = "得分>0";
                dataView.Sort = "得分 DESC";
                score = dataView.ToTable();
                dataGridView3.DataSource = score;
                //分配
                DataRow dr; //遍历的每一行记录
                DataRow[] gids;//每个队伍在算分表中的所有记录ID
                DataRow row_group;
                DataRow row_teacher;

                for (int i = 0; i < score.Rows.Count; i++)
                {
                    dr = score.Rows[i];
                    int tid, gid, assigned, t_rescount;

                    gid = Convert.ToInt32(dr["组ID"]);
                    tid = Convert.ToInt32(dr["老师ID"]);
                    assigned = Convert.ToInt32(dr["已分配"]);
                    row_teacher = t_res.Select("id='" + tid + "'")[0];
                    //row_teacher = sco.Select("tid=" + tid)[0];
                    row_group = g_res.Select("g_id='" + gid + "'")[0];
                    t_rescount = Convert.ToInt32(row_teacher["res_count"]);

                    if (assigned == 1)
                        continue;

                    gids = score.Select("组ID=" + gid);

                    for (int n = 0; n < T_groups; n++)
                    {
                        if (t_rescount == T_groups)
                            break;

                        int t_gchoice = Convert.ToInt32(row_teacher["g" + (n + 1)]);
                        if (t_gchoice == -1)
                        {
                            row_teacher["g" + (n + 1)] = gid;
                            row_teacher["res_count"] = t_rescount + 1;
                            row_group["t"] = tid;
                            for (int j = 0; j < gids.Length; j++)
                                gids[j]["已分配"] = 1;
                            break;
                        }
                        else
                            continue;
                    }
                }
            }
            else 
            {
                MessageBox.Show("未查询表!");
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (o == 2)
            {
                DataView data = t_res.DefaultView;
                DataTable temtable = data.ToTable(true, "id", "g1", "g2", "g3", "g4", "g5", "res_count", "t_grade", "t_major");
                BLL.GetinTea upt = new BLL.GetinTea();
                if (upt.updatetem(temtable))
                {
                    MessageBox.Show("保存成功!");
                }

                //BLL.GetinStu upg = new BLL.GetinStu();
                ////if (upg.updateg(g_res))
                ////MessageBox.Show("更新完成!");

                //BLL.GetinTea upt = new BLL.GetinTea();
                //if (upt.updatet(t_res) && upg.updateg(g_res))
                //    MessageBox.Show("更新完成!");
            }
            else 
            {
                MessageBox.Show("未分配！");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            BLL.GetinTea bll = new BLL.GetinTea();
            DataTable tablet = bll.teacher();
            MessageBox.Show("发布成功!");
        }

        void maketable()
        {
            sco = new DataTable();
            sco.Columns.Add("tid", Type.GetType("System.Int32"));
            sco.Columns.Add("g1", Type.GetType("System.Int32"));
            sco.Columns.Add("g2", Type.GetType("System.Int32"));
            sco.Columns.Add("g3", Type.GetType("System.Int32"));
            sco.Columns.Add("g4", Type.GetType("System.Int32"));
            sco.Columns.Add("g5", Type.GetType("System.Int32"));
            sco.Columns.Add("res_count", Type.GetType("System.Int32"));
            sco.Columns.Add("t_grade", Type.GetType("System.Int32"));
            sco.Columns.Add("t_major", Type.GetType("System.Int32"));

        }

        private void button5_Click(object sender, EventArgs e)
        {
            fpjg a = new fpjg();
            a.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            o=1;
            Model.fenpei fp = new Model.fenpei();
            fp.grade = comboBox1.Text;
            fp.profession = comboBox2.Text;

            BLL.GetinStu stu = new BLL.GetinStu();
            g = stu.fenpeig(fp);
            dataGridView1.DataSource = g;

            BLL.GetinTea tea = new BLL.GetinTea();
            t = tea.fenpeig(fp);
            dataGridView2.DataSource = t;

            make_table();
            dataGridView3.DataSource = score;

            count_score();
            t_res = t.Copy();
            g_res = g.Copy();
            dataGridView4.DataSource = g_res;
            dataGridView5.DataSource = t_res;
        }
    }
}
