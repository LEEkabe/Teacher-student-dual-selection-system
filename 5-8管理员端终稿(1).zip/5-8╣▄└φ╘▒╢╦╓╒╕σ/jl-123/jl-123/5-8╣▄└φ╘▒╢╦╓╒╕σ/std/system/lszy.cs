﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class lszy : Form
    {
        int x;
        int y;
        string v;
        DataTable t;
        DataTable dt_teacher;
        BLL.GetinTea Tea = new BLL.GetinTea();
        public lszy()
        {
            InitializeComponent();
        }

        private void lszy_Load(object sender, EventArgs e)
        {

            BLL.GetinTea tea = new BLL.GetinTea();
            t = tea.selectt();
            dataGridView1.DataSource = t;         
            dataGridView1.Columns["id"].HeaderText = "工号";
            dataGridView1.Columns["d1id"].HeaderText = "志愿一";
            dataGridView1.Columns["d2id"].HeaderText = "志愿二";
            dataGridView1.Columns["d3id"].HeaderText = "志愿三";
            dataGridView1.Columns["d4id"].HeaderText = "志愿四";
            dataGridView1.Columns["d5id"].HeaderText = "志愿五"; 
            dataGridView1.Columns["t_grade"].HeaderText = "年级";
            dataGridView1.Columns["t_major"].HeaderText = "专业";
        }
        private void dataGridView1_CellBeginEdit_1(object sender, DataGridViewCellCancelEventArgs e)
        {
            x = dataGridView1.CurrentCell.RowIndex;//
            y = dataGridView1.CurrentCell.ColumnIndex;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            v = Convert.ToString(dataGridView1[x, y].Value);
            t.Rows[y][x] = v;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Model.tea model = new Model.tea();
            model.grade = comboBox2.Text;
            model.profession = comboBox1.Text;
            BLL.GetinTea bll = new BLL.GetinTea();
            dt_teacher = bll.lszy(model);
            this.dataGridView1.DataSource = dt_teacher;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainform f = new mainform();
            f.ShowDialog();
        }
    }
}
