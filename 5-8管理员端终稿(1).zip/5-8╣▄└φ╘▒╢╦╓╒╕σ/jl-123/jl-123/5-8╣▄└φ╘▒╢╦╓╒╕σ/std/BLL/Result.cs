﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BLL
{
    public class Result
    {

        public DataTable sstu(Model.Result result)
        {
            DAL.Result re = new DAL.Result();
            DataTable res = re.sstu(result);
            return res;

        }

        public DataTable stea(Model.Result result)
        {
            DAL.Result re = new DAL.Result();
            DataTable res = re.stea(result);
            return res;

        }
    }
}