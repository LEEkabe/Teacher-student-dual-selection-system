﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace BLL
{
    public class import
    {
        DAL.import d = new DAL.import();
        public bool INstu(Model.stu m)
        {

            bool res = d.INstu(m);

            return res;
        }
        public bool INtech(Model.tea m)
        {

            bool res = d.INtech(m);

            return res;
        }
    }
}

