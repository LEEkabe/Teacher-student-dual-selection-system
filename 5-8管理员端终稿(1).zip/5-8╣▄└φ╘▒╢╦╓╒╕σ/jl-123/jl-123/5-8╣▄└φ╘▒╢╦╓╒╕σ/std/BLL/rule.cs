﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace BLL
{
    public class rule
    {
        DAL.rule messT = new DAL.rule();

        public bool guize1(Model.rule table)
        {

            bool mT = messT.guize1(table);

            return true;
        }
        public bool guize2(Model.rule table)
        {

            bool mT = messT.guize2(table);

            return true;
        }
    }
}
