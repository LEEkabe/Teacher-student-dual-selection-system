﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace BLL
{
   public class messTable
    {
       DAL.messTable messT = new DAL.messTable();
        Model.messTable mess = new Model.messTable();

       public bool messTrue(Model.messTable table)
       {
           
           bool mT = messT.messTrue(table);

           return true;
       }
       public DataTable select()
       {
           DataTable res = messT.select();
           return res;
       }

       public DataTable selectadm()
       {
           DataTable res = messT.selectadm();
           return res;
       }
       public bool update(DataTable s)
       {
           bool res = messT.update(s);
           return res;
       }

        public bool Del(Model.messTable mess, out string msg)
        {
            int res = messT.Delete(mess);
            if (res == 1)
            {
                msg = "ok!";
                return true;
            }
            else
            {
                msg = "no!";
                return false;
            }
        }
    }
}
