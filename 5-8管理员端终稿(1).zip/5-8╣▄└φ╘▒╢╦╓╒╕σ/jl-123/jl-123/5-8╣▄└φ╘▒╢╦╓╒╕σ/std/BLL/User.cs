﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class User
    {

        DAL.User d_user = new DAL.User();
        public int Login(Model.User m_user)
        {
            
            int res = d_user.Login(m_user);
            
            int b_res;

            if(res == 0)
                b_res = 0;
            else if(res == 1)
                b_res = 1;
            else
                b_res = 2;

            return b_res;
        }

        public bool update(Model.User user, out string msg)
        {
            bool res = false;
            res = d_user.update(user, out msg);
            return res;
        }
    }
}
