﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BLL
{
      public class fenpei
    {
            public DataTable select()
            {
                DAL.fenpei f= new DAL.fenpei();
                DataTable res = f.select();
                return res;
            }

            public DataTable temtable()
            {
                DAL.fenpei f = new DAL.fenpei();
                DataTable res = f.temtable();
                return res;
            }
            public bool uptemtable(DataTable s)
            {
                DAL.fenpei f = new DAL.fenpei();
                bool res = f.uptemtable(s);
                return res;
            }
    }
}
