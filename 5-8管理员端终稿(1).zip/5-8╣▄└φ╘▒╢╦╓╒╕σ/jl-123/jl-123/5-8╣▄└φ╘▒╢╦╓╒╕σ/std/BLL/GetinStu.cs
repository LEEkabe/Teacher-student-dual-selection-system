﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class GetinStu
    {
        DAL.GetinStu Stu = new DAL.GetinStu();
        public DataTable select()
        {
            DataTable res = Stu.select();
            return res;
        }
        public DataTable printgroup()
        {
            DataTable res = Stu.printgroup();
            return res;
        }

        public DataTable selectg()
        {
            DataTable res = Stu.selectg();
            return res;
        }
        public DataTable fenpeig(Model.fenpei fp)
        {
            DataTable res = Stu.fenpeig(fp);
            return res;
        }
        public bool updateg(DataTable g) 
        {
            bool res = Stu.updateg(g);
            return res;
        }
        public bool ups(DataTable s)
        {
            bool res = Stu.ups(s);
            return res;
        }
        public bool upst(DataTable s)
        {
            bool res = Stu.upst(s);
            return res;
        }


        public DataTable getList()
        {
            DataTable dt;
            DAL.GetinStu stu = new DAL.GetinStu();
            dt = stu.getList();
            return dt;
        }
        public bool updateList(DataTable dt)
        {
            bool res;
            DAL.GetinStu stu = new DAL.GetinStu();
            res = stu.updateList(dt);

            return res;
        }
        public DataTable Getstudent(Model.stu studentinfo)
        {
            DAL.GetinStu d_t = new DAL.GetinStu();
            DataTable dt = d_t.Getstudent(studentinfo);
            return dt;
        }
        public DataTable Getstudenta(Model.stu studentinfo)
        {
            DAL.GetinStu d_t = new DAL.GetinStu();
            DataTable dt = d_t.Getstudenta(studentinfo);
            return dt;
        }
        public DataTable Getstudentb(Model.stu studentinfo)
        {
            DAL.GetinStu d_t = new DAL.GetinStu();
            DataTable dt = d_t.Getstudentb(studentinfo);
            return dt;
        }
        public DataTable Getstudentc(Model.stu studentinfo)
        {
            DAL.GetinStu d_t = new DAL.GetinStu();
            DataTable dt = d_t.Getstudentc(studentinfo);
            return dt;
        }

        public bool addstudent(Model.stu stu)
        {
            DAL.GetinStu d_t = new DAL.GetinStu();
            bool mT = d_t.addstudent(stu);
            return true;
        }

    }
}
