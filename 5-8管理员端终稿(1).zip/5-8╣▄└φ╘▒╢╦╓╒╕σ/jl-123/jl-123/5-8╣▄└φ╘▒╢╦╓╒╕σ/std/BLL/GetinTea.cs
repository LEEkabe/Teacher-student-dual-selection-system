﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class GetinTea
    {
        int x;
        int y;
        string v;
        DAL.GetinTea Tea = new DAL.GetinTea();
        public DataTable select()
        {
          
            DataTable res = Tea.select();
            return res;
        }
        public DataTable selectt()
        {

            DataTable res = Tea.selectt();
            return res;
        }
        public DataTable fenpeig(Model.fenpei fp)
        {
            DataTable res = Tea.fenpeig(fp);
            return res;
        }
        public bool updatet(DataTable t)
        {
            bool res = Tea.updatet(t);
            return res;
        }
        public bool updatetea(DataTable t)
        {
            bool res = Tea.updatetea(t);
            return res;
        }
        public DataTable Getteacher(Model.tea teacherinfo)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.Getteacher(teacherinfo);
            return dt;
        }
        public DataTable lszy(Model.tea teacherinfo)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.lszy(teacherinfo);
            return dt;
        }
        public DataTable Getteachera(Model.tea teacherinfo)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.Getteachera(teacherinfo);
            return dt;
        }
        public DataTable Getteacherb(Model.tea teacherinfo)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.Getteacherb(teacherinfo);
            return dt;
        }
        public DataTable Getteacherc(Model.tea teacherinfo)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.Getteacherc(teacherinfo);
            return dt;
        }

        public bool updatetem(DataTable t)
        {
            bool res = Tea.updatetem(t);
            return res;
        }
        public DataTable teacher()
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            DataTable dt = d_t.teacher();
            return dt;
        }
        public bool addtea(Model.tea tea)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            bool mT = d_t.addtea(tea);
            return true;
        }

        public bool addteacher(Model.tea tea)
        {
            DAL.GetinTea d_t = new DAL.GetinTea();
            bool mT = d_t.addteacher(tea);
            return true;
        }

        public DataTable printtea()
        {

            DataTable res = Tea.printtea();
            return res;
        }
    }
}
