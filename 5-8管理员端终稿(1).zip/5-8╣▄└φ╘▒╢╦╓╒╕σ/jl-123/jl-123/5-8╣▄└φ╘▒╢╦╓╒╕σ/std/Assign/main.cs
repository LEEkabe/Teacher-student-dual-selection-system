﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//判断超过指定日期、加上循环几次失效、登陆代码。
        //{
        //    if ((textBox1.Text != null) && (textBox2.Text != null))
        //    {
        //        if (textBox1.Text == "admin2" && textBox2.Text == "12345")
        //        {
        //            login1 m = new login1();
        //            m.ShowDialog();
        //        }
        //        else
        //        {
        //            MessageBox.Show("用户名或密码错误");
        //            textBox1.Text = "";
        //            textBox2.Text = "";
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("请输入用户名和密码", "提示");
        //    }
        {
            string uid = textBox1.Text;//得到用户名和密码
            string pwd = textBox2.Text;

            Model.User m_user = new Model.User();
            m_user.Id = uid;
            m_user.Pwd = pwd;

            BLL.User b_user = new BLL.User();
            int res = b_user.Login(m_user);
            if (res == 0)
            {
                this.DialogResult = DialogResult.OK;
                login1 m = new login1();
                m.ShowDialog();
                this.Hide();
            }
            else if (res == 1)
                MessageBox.Show("用户名和密码不对！");

        }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
}
